#include "draw.hpp"

bool hsdisped = false;

int selectedR = -1, selectedC = -1;
int moves[MAX_MOVES][4];
int jumpMoves[MAX_MOVES][4];
int board[SIZE][SIZE];
int selectedMenuOption = 0;

int hs1_count = 0;
int hs2_count = 0;
int hsai_count = 0;
int moves1 = 0;
int moves2 = 0;
int currentPlayer = 1;
bool darkTheme = false;
bool ai_mode = false;

Color lightBoardColor1(240, 217, 181);
Color lightBoardColor2(181, 136, 99);
Color darkBoardColor1(60, 70, 80);
Color darkBoardColor2(30, 40, 50);
Color black_trans(0, 0, 0, 0);
Color black(0, 0, 0);


void drawBoard(RenderWindow& window, float width, float height) {
    RectangleShape cell(Vector2f(width, height));
    Texture crownTexture;
    crownTexture.loadFromFile("C:/Users/LENOVO/source/repos/SFML/SFML/kingcrown.png");
    Texture crownTexture2;
    crownTexture2.loadFromFile("C:/Users/LENOVO/source/repos/SFML/SFML/kingcrown2.png");

    Color color1 = darkTheme ? darkBoardColor1 : lightBoardColor1;
    Color color2 = darkTheme ? darkBoardColor2 : lightBoardColor2;

    for (int r = 0; r < SIZE; r++) {
        for (int c = 0; c < SIZE; c++) {
            if ((r + c) % 2 == 0)
                cell.setFillColor(color1);
            else
                cell.setFillColor(color2);

            cell.setPosition(Vector2f((c * width), (r * height)));
            window.draw(cell);
        }
    }

    if (selectedR != -1 && selectedC != -1) {
        RectangleShape highlight(Vector2f(width, height));
        highlight.setPosition(Vector2f(static_cast<float>(selectedC * width), static_cast<float>(selectedR * height)));
        highlight.setFillColor(Color(255, 255, 0, 100));
        window.draw(highlight);
        int flag2 = 1;
        int directions[4] = { -2, -1, 1, 2 };
        for (int i = 0; i < 4; i++) {
            int dr = directions[i];
            for (int j = 0; j < 4; j++) {
                int dc = directions[j];
                if (abs(dr) != abs(dc)) continue;
                int r2 = selectedR + dr;
                int c2 = selectedC + dc;

                if (isValidMove(selectedR, selectedC, r2, c2, currentPlayer)) {
                    CircleShape dot(9.f);
                    dot.setFillColor(Color(50, 205, 50, 180));
                    dot.setPosition(Vector2f(
                        static_cast<float>(c2 * width + width / 2 - 8),
                        static_cast<float>(r2 * height + height / 2 - 8)
                    ));
                    window.draw(dot);
                }
            }
        }
    }
    float rad;
    if (width > height) {
        rad = height * 0.35f;
    }
    else
        rad = width * 0.35f;
    CircleShape piece(rad);
    piece.setOutlineThickness(2.5f);
    piece.setOutlineColor(Color(50, 50, 50));


    for (int r = 0; r < SIZE; r++) {
        for (int c = 0; c < SIZE; c++) {
            int p = board[r][c];
            if (p == 1 || p == 3) {
                piece.setFillColor(Color(194, 24, 7));
                piece.setPosition(Vector2f(
                    static_cast<float>(c * width) + ((width - (2.f * rad)) / 2.f),
                    static_cast<float>(r * height) + ((height - (2.f * rad)) / 2.f)
                ));
                window.draw(piece);

                if (p == 3) {
                    Sprite crown(crownTexture);
                    float targetSize = width * 0.6f;
                    Vector2u texSize = crownTexture.getSize();
                    float scale = targetSize / texSize.x;
                    crown.setScale(sf::Vector2f(scale, scale));
                    crown.setPosition(Vector2f(static_cast<float>(c * width) + width * 0.2f,
                        static_cast<float>(r * height) + height * 0.2f));
                    window.draw(crown);
                }
            }
            else if (p == 2 || p == 4) {
                piece.setFillColor(Color(0, 0, 0));
                piece.setPosition(Vector2f(
                    static_cast<float>(c * width) + ((width - (2.f * rad)) / 2.f),
                    static_cast<float>(r * height) + ((height - (2.f * rad)) / 2.f)
                ));
                window.draw(piece);

                if (p == 4) {
                    sf::Sprite crown2(crownTexture2);
                    float targetSize = width * 0.6f;
                    Vector2u texSize = crownTexture2.getSize();
                    float scale = targetSize / texSize.x;
                    crown2.setScale(sf::Vector2f(scale, scale));
                    crown2.setPosition(Vector2f(static_cast<float>(c * width) + width * 0.2f,
                        static_cast<float>(r * height) + height * 0.2f));
                    // Draw
                    window.draw(crown2);
                }
            }
        }
    }
}

void drawMenu(RenderWindow& window, Font& font, float windowSize) {
    float ratiox = static_cast<float>(window.getSize().x) / 480.f;
    float ratioy = static_cast<float>(window.getSize().y) / 480.f;
    Color bgColor = darkTheme ? Color(181, 136, 99) : Color(240, 217, 181);
    window.clear(bgColor);

    Text title(font);
    title.setString("CHECKERS");
    title.setCharacterSize(70 * (ratiox < ratioy ? ratiox : ratioy));
    title.setFillColor(darkTheme ? Color(240, 217, 181) : Color(181, 136, 99));
    title.setStyle(Text::Bold);
    FloatRect titleBounds = title.getLocalBounds();
    title.setPosition(Vector2f(windowSize / 2.f - titleBounds.size.x / 2.f, 40.f * ratioy));
    window.draw(title);

    const char* options[4] = { "New Game", "Continue", "Settings", "Quit" };
    for (int i = 0; i < 4; i++) {
        RectangleShape button(Vector2f(280.f * ratiox, 50.f * ratioy));
        button.setPosition(Vector2f(windowSize / 2.f - (140.f * ratiox), (160.f + i * 70.f) * ratioy));

        if (i == selectedMenuOption) {
            button.setFillColor(darkTheme ? Color(240, 217, 181) : Color(181, 136, 99)); // selected button is lighter
        }
        else {
            button.setFillColor(darkTheme ? Color(181, 136, 99) : Color(240, 217, 181)); // unselected button is darker
        }
        window.draw(button);

        Text optionText(font);
        optionText.setString(options[i]);
        optionText.setCharacterSize(24 * (ratiox < ratioy ? ratiox : ratioy));
        optionText.setFillColor(i == selectedMenuOption
            ? (darkTheme ? Color(181, 136, 99) : Color(240, 217, 181))  // text opposite to button
            : (darkTheme ? Color(240, 217, 181) : Color(181, 136, 99))
        );
        FloatRect textBounds = optionText.getLocalBounds();
        optionText.setPosition(Vector2f(
            windowSize / 2.f - textBounds.size.x / 2.f,
            (168.f + i * 70.f) * ratioy
        ));
        window.draw(optionText);
    }
    window.display();
}

void drawSettings(RenderWindow& window, Font& font, RectangleShape& bbox1, float windowSize) {
    float ratiox = static_cast<float>(window.getSize().x) / 480.f;
    float ratioy = static_cast<float>(window.getSize().y) / 480.f;
    Color bgColor = darkTheme ? Color(181, 136, 99) : Color(240, 217, 181);
    window.clear(bgColor);

    Text title(font);
    title.setString("SETTINGS");
    title.setCharacterSize(50 * (ratiox < ratioy ? ratiox : ratioy));
    title.setFillColor(darkTheme ? Color(240, 217, 181) : Color(181, 136, 99));
    title.setStyle(Text::Bold);
    FloatRect titleBounds = title.getLocalBounds();
    title.setPosition(Vector2f(windowSize / 2.f - titleBounds.size.x / 2.f, 60.f * ratioy));
    window.draw(title);

    Text themeLabel(font);
    themeLabel.setString("Theme:");
    themeLabel.setCharacterSize(24 * (ratiox < ratioy ? ratiox : ratioy));
    themeLabel.setFillColor(darkTheme ? Color(240, 217, 181) : Color(181, 136, 99));
    themeLabel.setPosition(Vector2f(80.f * ratiox, 180.f * ratioy));
    window.draw(themeLabel);

    RectangleShape lightButton(Vector2f(120.f * ratiox, 45.f * ratioy));
    lightButton.setPosition(Vector2f(100.f * ratiox, 230.f * ratioy));
    lightButton.setFillColor(darkTheme ? Color(240, 217, 181) : Color(181, 136, 99));
    lightButton.setOutlineThickness(2.f);
    lightButton.setOutlineColor(Color(0, 0, 0));
    window.draw(lightButton);

    Text lightText(font);
    lightText.setString("Light");
    lightText.setCharacterSize(20 * (ratiox < ratioy ? ratiox : ratioy));
    lightText.setFillColor(darkTheme ? Color(25, 25, 35) : Color(50, 50, 70));
    FloatRect lightBounds = lightText.getLocalBounds();
    lightText.setPosition(Vector2f(160.f * ratiox - lightBounds.size.x / 2.f, 240.f * ratioy));
    window.draw(lightText);

    RectangleShape darkButton(Vector2f(120.f * ratiox, 45.f * ratioy));
    darkButton.setPosition(Vector2f(260.f * ratiox, 230.f * ratioy));
    darkButton.setFillColor(darkTheme ? Color(181, 136, 99) : Color(240, 217, 181));
    darkButton.setOutlineThickness(2.f);
    darkButton.setOutlineColor(Color(0, 0, 0));
    window.draw(darkButton);

    Text darkText(font);
    darkText.setString("Dark");
    darkText.setCharacterSize(20 * (ratiox < ratioy ? ratiox : ratioy));
    darkText.setFillColor(darkTheme ? Color(25, 25, 35) : Color(50, 50, 70));
    FloatRect darkBounds = darkText.getLocalBounds();
    darkText.setPosition(Vector2f(320.f * ratiox - darkBounds.size.x / 2.f, 240.f * ratioy));
    window.draw(darkText);

    Text modeLabel(font);
    modeLabel.setString("Leaderboard:");
    modeLabel.setCharacterSize(24 * (ratiox < ratioy ? ratiox : ratioy));
    modeLabel.setFillColor(darkTheme ? Color(240, 217, 181) : Color(181, 136, 99));
    modeLabel.setPosition(Vector2f(80.f * ratiox, 300.f * ratioy));
    window.draw(modeLabel);

    RectangleShape ai(Vector2f(120.f * ratiox, 45.f * ratioy));
    ai.setPosition(Vector2f(100.f * ratiox, 350.f * ratioy));
    ai.setFillColor(!ai_mode ? (darkTheme ? Color(181, 136, 99) : Color(240, 217, 181))
        : (darkTheme ? Color(240, 217, 181) : Color(181, 136, 99)));
    ai.setOutlineThickness(2.f);
    ai.setOutlineColor(Color(0, 0, 0));
    window.draw(ai);

    Text aiText(font);
    aiText.setString("P1 VS AI");
    aiText.setCharacterSize(20 * (ratiox < ratioy ? ratiox : ratioy));
    aiText.setFillColor(!ai_mode ? (darkTheme ? Color(25, 25, 35) : Color(50, 50, 70))
        : (darkTheme ? Color(25, 25, 35) : Color(50, 50, 70)));
    FloatRect aiBounds = aiText.getLocalBounds();
    aiText.setPosition(Vector2f(160.f * ratiox - aiBounds.size.x / 2.f, 360.f * ratioy));
    window.draw(aiText);

    RectangleShape human(Vector2f(120.f * ratiox, 45.f * ratioy));
    human.setPosition(Vector2f(260.f * ratiox, 350.f * ratioy));
    human.setFillColor(!ai_mode ? (darkTheme ? Color(240, 217, 181) : Color(181, 136, 99))
        : (darkTheme ? Color(181, 136, 99) : Color(240, 217, 181)));
    human.setOutlineThickness(2.f);
    human.setOutlineColor(Color(0, 0, 0));
    window.draw(human);

    Text humanText(font);
    humanText.setString("P1 VS P2");
    humanText.setCharacterSize(20 * (ratiox < ratioy ? ratiox : ratioy));
    humanText.setFillColor(!ai_mode ? (darkTheme ? Color(25, 25, 35) : Color(50, 50, 70))
        : (darkTheme ? Color(25, 25, 35) : Color(50, 50, 70)));
    FloatRect humanBounds = humanText.getLocalBounds();
    humanText.setPosition(Vector2f(320.f * ratiox - humanBounds.size.x / 2.f, 360.f * ratioy));
    window.draw(humanText);

    Text backText(font);
    backText.setString("Press ESC to go back");
    backText.setCharacterSize(16 * (ratiox < ratioy ? ratiox : ratioy));
    backText.setFillColor(darkTheme ? Color(240, 217, 181) : Color(181, 136, 99));
    FloatRect backBounds = backText.getLocalBounds();
    backText.setPosition(Vector2f(windowSize / 2.f - backBounds.size.x / 2.f, 450.f * ratioy));
    window.draw(backText);

    window.draw(bbox1);
    window.display();
}

void drawModePage(RenderWindow& window, Font& font, RectangleShape& bbox3, float windowSize) {
    float ratiox = static_cast<float>(window.getSize().x) / 480.f;
    float ratioy = static_cast<float>(window.getSize().y) / 480.f;
    Color bgColor = darkTheme ? Color(181, 136, 99) : Color(240, 217, 181);
    window.clear(bgColor);

    Text title(font);
    title.setString("SELECT MODE");
    title.setCharacterSize(50 * (ratiox < ratioy ? ratiox : ratioy));
    title.setFillColor(darkTheme ? Color(240, 217, 181) : Color(181, 136, 99));
    title.setStyle(Text::Bold);
    FloatRect titleBounds = title.getLocalBounds();
    title.setPosition(Vector2f(windowSize / 2.f - titleBounds.size.x / 2.f, 60.f * ratioy));
    window.draw(title);

    RectangleShape aiButton(Vector2f(120.f * ratiox, 45.f * ratioy));
    aiButton.setPosition(Vector2f(100.f * ratiox, 230.f * ratioy));
    aiButton.setFillColor(!ai_mode ? (darkTheme ? Color(181, 136, 99) : Color(240, 217, 181))
        : (darkTheme ? Color(240, 217, 181) : Color(181, 136, 99)));
    aiButton.setOutlineThickness(2.f);
    aiButton.setOutlineColor(Color(0, 0, 0));
    window.draw(aiButton);

    Text aiText(font);
    aiText.setString("AI");
    aiText.setCharacterSize(20 * (ratiox < ratioy ? ratiox : ratioy));
    aiText.setFillColor(!ai_mode ? (darkTheme ? Color(25, 25, 35) : Color(50, 50, 70))
        : (darkTheme ? Color(25, 25, 35) : Color(50, 50, 70)));
    FloatRect lightBounds = aiText.getLocalBounds();
    aiText.setPosition(Vector2f(160.f * ratiox - lightBounds.size.x / 2.f, 240.f * ratioy));
    window.draw(aiText);

    RectangleShape humanButton(Vector2f(120.f * ratiox, 45.f * ratioy));
    humanButton.setPosition(Vector2f(260.f * ratiox, 230.f * ratioy));
    humanButton.setFillColor(!ai_mode ? (darkTheme ? Color(240, 217, 181) : Color(181, 136, 99))
        : (darkTheme ? Color(181, 136, 99) : Color(240, 217, 181)));
    humanButton.setOutlineThickness(2.f);
    humanButton.setOutlineColor(Color(0, 0, 0));
    window.draw(humanButton);

    Text humanText(font);
    humanText.setString("Human");
    humanText.setCharacterSize(20 * (ratiox < ratioy ? ratiox : ratioy));
    humanText.setFillColor(!ai_mode ? (darkTheme ? Color(25, 25, 35) : Color(50, 50, 70))
        : (darkTheme ? Color(25, 25, 35) : Color(50, 50, 70)));
    FloatRect darkBounds = humanText.getLocalBounds();
    humanText.setPosition(Vector2f(320.f * ratiox - darkBounds.size.x / 2.f, 240.f * ratioy));
    window.draw(humanText);

    Text backText(font);
    backText.setString("Press ESC to go back");
    backText.setCharacterSize(16 * (ratiox < ratioy ? ratiox : ratioy));
    backText.setFillColor(darkTheme ? Color(240, 217, 181) : Color(181, 136, 99));
    FloatRect backBounds = backText.getLocalBounds();
    backText.setPosition(Vector2f(windowSize / 2.f - backBounds.size.x / 2.f, 450.f * ratioy));
    window.draw(backText);

    window.draw(bbox3);
    window.display();
}

void drawHighscoreHuman(RenderWindow& window, Font& font, float windowSize) {
    int hs1c;
    int hs2c;
    fstream hs1("hs1.txt");
    fstream hs2("hs2.txt");
    fstream hscount1("hs1_count.txt");
    fstream hscount2("hs2_count.txt");
    float ratiox = static_cast<float>(window.getSize().x) / 480.f;
    float ratioy = static_cast<float>(window.getSize().y) / 480.f;
    Color bgColor = darkTheme ? Color(181, 136, 99) : Color(240, 217, 181);
    window.clear(bgColor);

    const char* titleText = "LEADERBOARD [P1 VS P2]";
    Text title(font);
    title.setString(titleText);
    title.setCharacterSize(30 * (ratiox < ratioy ? ratiox : ratioy));
    title.setFillColor(darkTheme ? Color(240, 217, 181) : Color(181, 136, 99));
    title.setStyle(Text::Bold);
    FloatRect resultBounds = title.getLocalBounds();
    title.setPosition(Vector2f(windowSize / 2.f - resultBounds.size.x / 2.f, 20.f * ratioy));
    window.draw(title);

    const char* P1Text = "Player 1";
    Text P1(font);
    P1.setString(P1Text);
    P1.setCharacterSize(25 * (ratiox < ratioy ? ratiox : ratioy));
    P1.setFillColor(darkTheme ? Color(240, 217, 181) : Color(181, 136, 99));
    P1.setStyle(Text::Bold);
    FloatRect P1Bounds = P1.getLocalBounds();
    P1.setPosition(Vector2f((windowSize / 2.f - P1Bounds.size.x / 2.f) / 4.f, 100.f * ratioy - 30.f));
    window.draw(P1);

    const char* P2Text = "Player 2";
    Text P2(font);
    P2.setString(P2Text);
    P2.setCharacterSize(25 * (ratiox < ratioy ? ratiox : ratioy));
    P2.setFillColor(darkTheme ? Color(240, 217, 181) : Color(181, 136, 99));;
    P2.setStyle(Text::Bold);
    FloatRect P2Bounds = P2.getLocalBounds();
    P2.setPosition(Vector2f((windowSize / 2.f - P2Bounds.size.x / 2.f) * 1.75f, 100.f * ratioy - 30.0f));
    window.draw(P2);

    hscount1 >> hs1c;
    hscount2 >> hs2c;
    string c;
    for (int i = 1; i <= hs1c; i++) {
        hs1 >> c;
        Text highscore(font);
        highscore.setString(c);
        highscore.setCharacterSize(15 * (ratiox < ratioy ? ratiox : ratioy));
        highscore.setFillColor(darkTheme ? Color(240, 217, 181) : Color(181, 136, 99));;
        highscore.setStyle(Text::Bold);
        FloatRect resultBounds = highscore.getLocalBounds();
        highscore.setPosition(Vector2f((windowSize / 2.f - resultBounds.size.x / 2.f) / 2.8f, 95.f + (i * 280.f) / 4.f * ratioy));
        window.draw(highscore);
    }

    for (int i = 1; i <= hs2c; i++) {
        hs2 >> c;
        Text highscore(font);
        highscore.setString(c);
        highscore.setCharacterSize(15 * (ratiox < ratioy ? ratiox : ratioy));
        highscore.setFillColor(darkTheme ? Color(240, 217, 181) : Color(181, 136, 99));;
        highscore.setStyle(Text::Bold);
        FloatRect resultBounds = highscore.getLocalBounds();
        highscore.setPosition(Vector2f((windowSize / 2.f - resultBounds.size.x / 2.f) * 1.6f, 95.f + (i * 280.f) / 4.f * ratioy));
        window.draw(highscore);
    }

    hs1.close();
    hs2.close();
    hscount1.close();
    hscount2.close();
    window.display();
}

void drawHighscoreAi(RenderWindow& window, Font& font, float windowSize) {
    int hsc;
    fstream hs("hs_ai.txt");
    fstream hscount("hsai_count.txt");
    float ratiox = static_cast<float>(window.getSize().x) / 480.f;
    float ratioy = static_cast<float>(window.getSize().y) / 480.f;

    Color bgColor = darkTheme ? Color(181, 136, 99) : Color(240, 217, 181);
    window.clear(bgColor);

    const char* titleText = "LEADERBOARD [P1 VS AI]";
    Text title(font);
    title.setString(titleText);
    title.setCharacterSize(30 * (ratiox < ratioy ? ratiox : ratioy));
    title.setFillColor(darkTheme ? Color(240, 217, 181) : Color(181, 136, 99));
    title.setStyle(Text::Bold);
    FloatRect resultBounds = title.getLocalBounds();
    title.setPosition(Vector2f(windowSize / 2.f - resultBounds.size.x / 2.f, 30.f * ratioy));
    window.draw(title);

    hscount >> hsc;
    string c;
    for (int i = 1; i <= hsc; i++) {
        hs >> c;
        Text highscore(font);
        highscore.setString(c);
        highscore.setCharacterSize(15 * (ratiox < ratioy ? ratiox : ratioy));
        highscore.setFillColor(darkTheme ? Color(240, 217, 181) : Color(181, 136, 99));
        highscore.setStyle(Text::Bold);
        FloatRect resultBounds = highscore.getLocalBounds();
        highscore.setPosition(Vector2f(windowSize / 2.f - resultBounds.size.x / 2.f, i * 90.f * ratioy));
        window.draw(highscore);
    }
    hs.close();
    hscount.close();
    window.display();
}

void drawEndScreen(RenderWindow& window, Font& font, bool playerWon, float windowSize) {
    if (!hsdisped) {
        saveHighscores(playerWon);
        hsdisped = true;
    }

    initBoard();
    saveBoard();

    float ratiox = static_cast<float>(window.getSize().x) / 480.f;
    float ratioy = static_cast<float>(window.getSize().y) / 480.f;

    Color bgColor = darkTheme ? Color(25, 25, 35) : Color(40, 40, 50);
    window.clear(bgColor);

    const char* resultText = ai_mode ? (playerWon ? "YOU WON!" : "YOU LOSE!") : (playerWon ? "PLAYER 1 WON!" : "PLAYER 2 WON!");
    Text result(font);
    result.setString(resultText);
    result.setCharacterSize(50 * (ratiox < ratioy ? ratiox : ratioy));
    result.setFillColor(playerWon ? Color(100, 255, 100) : Color(255, 100, 100));
    result.setStyle(Text::Bold);
    FloatRect resultBounds = result.getLocalBounds();
    result.setPosition(Vector2f(windowSize / 2.f - resultBounds.size.x / 2.f, 120.f * ratioy));
    window.draw(result);

    const char* messageText = ai_mode ? (playerWon ? "Congratulations!" : "Better luck next time!") : (playerWon ? "Congratulations Player 1!" : "Congratulations Player 2!");
    Text message(font);
    message.setString(messageText);
    message.setCharacterSize(30 * (ratiox < ratioy ? ratiox : ratioy));
    message.setFillColor(Color(200, 200, 200));
    FloatRect msgBounds = message.getLocalBounds();
    message.setPosition(Vector2f(windowSize / 2.f - msgBounds.size.x / 2.f, 220.f * ratioy));
    window.draw(message);

    Text playAgain(font);
    playAgain.setString("Click to play again");
    playAgain.setCharacterSize(20 * (ratiox < ratioy ? ratiox : ratioy));
    playAgain.setFillColor(Color(180, 180, 180));
    FloatRect playBounds = playAgain.getLocalBounds();
    playAgain.setPosition(Vector2f(windowSize / 2.f - playBounds.size.x / 2.f, 300.f * ratioy));
    window.draw(playAgain);

    Text menu(font);
    menu.setString("Press ESC for main menu");
    menu.setCharacterSize(16 * (ratiox < ratioy ? ratiox : ratioy));
    menu.setFillColor(Color(160, 160, 160));
    FloatRect menuBounds = menu.getLocalBounds();
    menu.setPosition(Vector2f(windowSize / 2.f - menuBounds.size.x / 2.f, 380.f * ratioy));
    window.draw(menu);

    moves1 = 0;
    moves2 = 0;

    window.display();
}
