#ifndef DRAW_HPP
#define DRAW_HPP

#include <iostream>
#include <SFML/Graphics.hpp>
#include <fstream>
#include <cstdlib>
#include <ctime>
#include "move.hpp"
#include "save.hpp"

using namespace std;
using namespace sf;

constexpr const int SIZE = 8;
constexpr const int CELL_SIZE = 60;
constexpr const int MAX_MOVES = 100;

// Game states
constexpr const int STATE_MAIN_MENU = 0;
constexpr const int STATE_PLAYING = 1;
constexpr const int STATE_PLAYER_WON = 2;
constexpr const int STATE_PLAYER_LOST = 3;
constexpr const int STATE_SETTINGS = 4;
constexpr const int STATE_MODE = 5;
constexpr const int STATE_HSAI = 6;
constexpr const int STATE_HSHUMAN = 7;


extern bool darkTheme;
extern bool ai_mode;
extern bool hsdisped;
extern Color lightBoardColor1;
extern Color lightBoardColor2;
extern Color darkBoardColor1;
extern Color darkBoardColor2;
extern Color black_trans;
extern Color black;

extern int board[SIZE][SIZE];
extern int selectedR;
extern int selectedC;
extern int currentPlayer;
extern int gameState;
extern int selectedMenuOption;
extern int moves1;
extern int moves2;
extern int hs1_count;
extern int hs2_count;
extern int hsai_count;

// Move storage: [moveIndex][0=r1, 1=c1, 2=r2, 3=c2]
extern int moves[MAX_MOVES][4];
extern int jumpMoves[MAX_MOVES][4];


void drawBoard(RenderWindow& window, float width, float height);

void drawMenu(RenderWindow& window, Font& font, float windowSize);

void drawSettings(RenderWindow& window, Font& font, RectangleShape& bbox1, float windowSize);

void drawModePage(RenderWindow& window, Font& font, RectangleShape& bbox3, float windowSize);

void drawHighscoreHuman(RenderWindow& window, Font& font, float windowSize);

void drawHighscoreAi(RenderWindow& window, Font& font, float windowSize);

void drawEndScreen(RenderWindow& window, Font& font, bool playerWon, float windowSize);


#endif // !DRAW_HPP
