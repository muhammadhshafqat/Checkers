#include <SFML/Audio.hpp>
#include "draw.hpp"
#include "move.hpp"
#include "save.hpp"

using namespace std;
using namespace sf;

int gameState = STATE_MAIN_MENU;

int main()
{

    srand(static_cast<unsigned>(time(nullptr)));

    RenderWindow window(VideoMode(Vector2u(800, 800)), "Checker Mates", Style::Default);
    window.setFramerateLimit(60);

    auto [width, height] = window.getSize();
    float ratiox = static_cast<float>(width) / 480.f;
    float ratioy = static_cast<float>(height) / 480.f;

    RectangleShape bbox({ static_cast<float>(width) / 8.f , static_cast<float>(height) / 8.f });
    bbox.setPosition({ 0.f, 0.f });
    bbox.setOutlineThickness(-3.f); //-3
    bbox.setFillColor(black_trans);
    bbox.setOutlineColor(black);
    window.draw(bbox);
    int lr = 0, ud = 0;

    RectangleShape bbox1({ 120.f * ratiox, 45.f * ratioy });
    bbox1.setPosition({ 100.f * ratiox, 230.f * ratioy });
    bbox1.setOutlineThickness(4.f);
    bbox1.setFillColor(black_trans);
    bbox1.setOutlineColor(black);
    int lr1 = 0, lr2 = 0, ud1 = 0;

    RectangleShape bbox3({ 120.f * ratiox, 45.f * ratioy });
    bbox3.setPosition({ 100.f * ratiox, 230.f * ratioy });
    bbox3.setOutlineThickness(4.f);
    bbox3.setFillColor(black_trans);
    bbox3.setOutlineColor(black);

    Font font;
    font.openFromFile("C:/Users/LENOVO/source/repos/SFML/SFML/PixelifySans-SemiBold.ttf");

    Music backgroundMusic;
    if (!backgroundMusic.openFromFile("bgmusic.mp3")) {
        cerr << "Failed to load background music!" << endl;
    }
    else {
        backgroundMusic.setLooping(true);
        backgroundMusic.setVolume(5.f);
        backgroundMusic.play();
    }

    loadBoard();

    while (window.isOpen())
    {
        while (auto event = window.pollEvent())
        {
            if (event->is<Event::Closed>()) {
                saveBoard();
                window.close();
            }
            else if (event->is<Event::Resized>()) {
                auto [widthw, heightw] = window.getSize();
                width = widthw;
                height = heightw;
                float ratiox = static_cast<float>(width) / 480.f;
                float ratioy = static_cast<float>(height) / 480.f;
                auto [w1, h1] = bbox.getSize();
                auto [w2, h2] = bbox1.getSize();
                auto [x2, y2] = bbox1.getPosition();
                auto [x1, y1] = bbox.getPosition();
                int c = static_cast<float>(x1) / static_cast<float>(w1);
                int r = static_cast<float>(y1) / static_cast<float>(h1);
                FloatRect visibleArea({ 0, 0 }, { static_cast<float>(widthw), static_cast<float>(heightw) });
                window.setView(View(visibleArea));
                bbox.setSize(Vector2f(static_cast<float>(width) / 8.f, static_cast<float>(height) / 8.f));
                bbox.setPosition({ static_cast<float>(width * c) / 8.f, static_cast<float>(height * r) / 8.f });
                bbox1.setSize({ 120.f * ratiox, 45.f * ratioy });
                bbox3.setSize({ 120.f * ratiox, 45.f * ratioy });
                bbox1.setPosition({ (!lr1 ? 100.f : 260.f) * ratiox , (!ud1 ? 230.f : 350.f) * ratioy });
                bbox3.setPosition({ (!lr2 ? 100.f : 260.f) * ratiox , 230.f * ratioy });
            }

            if (auto* mousePress = event->getIf<Event::MouseButtonPressed>()) {
                if (mousePress->button == Mouse::Button::Left) {
                    if (gameState == STATE_MAIN_MENU) {
                        float ratiox = static_cast<float>(width) / 480.f;
                        float ratioy = static_cast<float>(height) / 480.f;
                        Vector2i mousePos = Mouse::getPosition(window);

                        // Button positions (same as drawMenu)
                        for (int i = 0; i < 4; i++) {
                            int x = width / 2 - 140 * ratiox;
                            int y = (160 + i * 70) * ratioy;

                            // Check click inside button
                            if (mousePos.x >= x && mousePos.x <= x + 280 * ratiox &&
                                mousePos.y >= y && mousePos.y <= y + 50 * ratioy)
                            {
                                cout << "i: " << i << endl;
                                cout << "x: " << x << "  " << "y: " << y << endl;
                                cout << mousePos.x << "  " << mousePos.y << endl;

                                if (i == 0) {
                                    gameState == STATE_MODE;
                                    // Select Mode
                                }
                                else if (i == 1) {    // Continue
                                    gameState = STATE_PLAYING;
                                }
                                else if (i == 2) {    // Settings
                                    gameState = STATE_SETTINGS;
                                }
                                else if (i == 3) {    // Quit
                                    saveBoard();
                                    window.close();
                                }
                            }
                        }
                    }
                    else if (gameState == STATE_SETTINGS) {
                        float ratiox = static_cast<float>(width) / 480.f;
                        float ratioy = static_cast<float>(height) / 480.f;
                        Vector2i mousePos = Mouse::getPosition(window);
                        if (mousePos.x >= 100 * ratiox && mousePos.x <= 220 * ratiox && mousePos.y >= 230 * ratioy && mousePos.y <= 275 * ratioy) {
                            darkTheme = false;
                        }
                        else if (mousePos.x >= 260 * ratiox && mousePos.x <= 380 * ratiox && mousePos.y >= 230 * ratioy && mousePos.y <= 275 * ratioy) {
                            darkTheme = true;
                        }
                        if (mousePos.x >= 100 * ratiox && mousePos.x <= 220 * ratiox && mousePos.y >= 350 * ratioy && mousePos.y <= 395 * ratioy) {
                            gameState = STATE_HSAI;
                        }
                        else if (mousePos.x >= 260 * ratiox && mousePos.x <= 380 * ratiox && mousePos.y >= 350 * ratioy && mousePos.y <= 395 * ratioy) {
                            gameState = STATE_HSHUMAN;
                        }
                    }
                    else if (gameState == STATE_MODE) {
                        Vector2i mousePos = Mouse::getPosition(window);
                        if (mousePos.x >= 100 * ratiox && mousePos.x <= 220 * ratiox && mousePos.y >= 230 * ratioy && mousePos.y <= 275 * ratioy) {
                            ai_mode = true;
                            initBoard();
                            currentPlayer = 1;
                            selectedR = selectedC = -1;
                            gameState = STATE_PLAYING;
                            moves1 = 0, moves2 = 0;
                        }
                        else if (mousePos.x >= 260 * ratiox && mousePos.x <= 380 * ratiox && mousePos.y >= 230 * ratioy && mousePos.y <= 275 * ratioy) {
                            ai_mode = false;
                            initBoard();
                            currentPlayer = 1;
                            selectedR = selectedC = -1;
                            gameState = STATE_PLAYING;
                            moves1 = 0, moves2 = 0;
                        }
                    }
                    else if (gameState == STATE_PLAYER_WON || gameState == STATE_PLAYER_LOST) {
                        initBoard();
                        lr1 = 0, lr2 = 0, ud1 = 0, lr = 0, ud = 0;
                        currentPlayer = 1;
                        selectedR = -1;
                        selectedC = -1;
                        gameState = STATE_MODE;
                        hsdisped = false;
                    }
                    else if (gameState == STATE_PLAYING) {
                        Vector2i mousePos = Mouse::getPosition(window);
                        int c = mousePos.x / (static_cast<float>(width) / 8.f);
                        int r = mousePos.y / (static_cast<float>(height) / 8.f);
                        bbox.setPosition({ static_cast<float>(width * c) / 8.f, static_cast<float>(height * r) / 8.f });
                        lr = c;
                        ud = r;
                        if (inside(r, c)) {
                            if (selectedR == -1) {
                                if (getPlayer(board[r][c]) == currentPlayer) {
                                    selectedR = r;
                                    selectedC = c;
                                }
                            }
                            else {
                                if (makeMove(selectedR, selectedC, r, c, currentPlayer)) {
                                    selectedR = -1;
                                    selectedC = -1;
                                    if (ai_mode) {
                                        if (currentPlayer == 1) {
                                            cout << "Player 1 Moves: " << moves1 << endl;
                                            moves1++;
                                            currentPlayer = 2;
                                        }
                                    }
                                    else {
                                        currentPlayer == 1 ? moves1++ : moves2++;
                                        cout << "Player 1 Moves: " << moves1 << "  Player 2 Moves: " << moves2 << endl;
                                        currentPlayer == 1 ? currentPlayer = 2 : currentPlayer = 1;
                                    }
                                }
                                else if (getPlayer(board[r][c]) == currentPlayer) {
                                    selectedR = r;
                                    selectedC = c;
                                }
                                else {
                                    selectedR = -1;
                                    selectedC = -1;
                                }
                            }
                        }
                    }
                }
            }

            if (event->is<Event::KeyPressed>()) {
                auto* keyPress = event->getIf<Event::KeyPressed>();

                if (keyPress->code == Keyboard::Key::Escape) {
                    if (gameState == STATE_SETTINGS || gameState == STATE_PLAYER_WON || gameState == STATE_PLAYER_LOST || gameState == STATE_MODE) {
                        gameState = STATE_MAIN_MENU;
                        hsdisped = false;
                    }
                    if (gameState == STATE_HSAI || gameState == STATE_HSHUMAN) {
                        gameState = STATE_SETTINGS;
                    }
                }

                if (gameState == STATE_SETTINGS) {
                    float ratiox = static_cast<float>(width) / 480.f;
                    float ratioy = static_cast<float>(height) / 480.f;
                    if (keyPress->code == Keyboard::Key::Right) {
                        if (lr1 != 1) {
                            bbox1.move({ 160.f * ratiox, 0.f });
                            lr1++;
                        }
                    }
                    if (keyPress->code == Keyboard::Key::Left) {
                        if (lr1 != 0) {
                            bbox1.move({ -160.f * ratiox, 0.f });
                            lr1--;
                        }
                    }
                    if (keyPress->code == Keyboard::Key::Down) {
                        if (ud1 != 1) {
                            bbox1.move({ 0.f, 120.f * ratioy });
                            ud1++;
                        }
                    }
                    if (keyPress->code == Keyboard::Key::Up) {
                        if (ud1 != 0) {
                            bbox1.move({ 0.f, -120.f * ratioy });
                            ud1--;
                        }
                    }
                    if (keyPress->code == Keyboard::Key::Enter) {
                        fstream f("theme.txt", ios::out);
                        f.seekg(0, ios::beg);
                        if (!ud1) {
                            if (!lr1) {
                                darkTheme = false;
                                f << darkTheme;
                            }
                            else {
                                darkTheme = true;
                                f << darkTheme;
                            }
                        }
                        else {
                            if (!lr1) {
                                gameState = STATE_HSAI;
                            }
                            else {
                                gameState = STATE_HSHUMAN;
                            }
                        }
                        f.close();
                    }
                }

                if (gameState == STATE_MODE) {
                    float ratiox = static_cast<float>(width) / 480.f;
                    float ratioy = static_cast<float>(height) / 480.f;
                    if (keyPress->code == Keyboard::Key::Right) {
                        if (lr2 != 1) {
                            bbox3.move({ 160.f * ratiox, 0.f });
                            lr2++;
                        }
                    }
                    if (keyPress->code == Keyboard::Key::Left) {
                        if (lr2 != 0) {
                            bbox3.move({ -160.f * ratiox, 0.f });
                            lr2--;
                        }
                    }
                    if (keyPress->code == Keyboard::Key::Enter) {
                        fstream f("mode.txt", ios::out);
                        f.seekg(0, ios::beg);
                        if (!lr2) {
                            ai_mode = true;
                            f << ai_mode;
                            initBoard();
                            currentPlayer = 1;
                            selectedR = selectedC = -1;
                            gameState = STATE_PLAYING;
                            moves1 = 0;
                            moves2 = 0;
                        }
                        else {
                            ai_mode = false;
                            f << ai_mode;
                            initBoard();
                            currentPlayer = 1;
                            selectedR = selectedC = -1;
                            gameState = STATE_PLAYING;
                            moves1 = 0;
                            moves2 = 0;
                        }
                        f.close();
                    }
                }

                if (gameState == STATE_PLAYING) {
                    if (keyPress->code == Keyboard::Key::S) {
                        saveBoard();
                    }
                    if (keyPress->code == Keyboard::Key::L) {
                        loadBoard();
                    }
                    if (keyPress->code == Keyboard::Key::R) {
                        initBoard();
                        currentPlayer = 1;
                        selectedR = -1;
                        selectedC = -1;
                    }
                    if (keyPress->code == Keyboard::Key::Escape) {
                        saveBoard();
                        gameState = STATE_MAIN_MENU;
                        selectedR = -1;
                        selectedC = -1;
                        selectedMenuOption = 0;
                    }
                    if (keyPress->code == Keyboard::Key::Down) {
                        if (ud < 7) {
                            bbox.move({ 0.f, static_cast<float>(height) / 8.f });
                            ud++;
                        }
                    }
                    if (keyPress->code == Keyboard::Key::Up) {
                        if (ud > 0) {
                            bbox.move({ 0.f, static_cast<float>(height) / -8.f });
                            ud--;
                        }
                    }
                    if (keyPress->code == Keyboard::Key::Right) {
                        if (lr < 7) {
                            bbox.move({ static_cast<float>(width) / 8.f, 0.f });
                            lr++;
                        }
                    }
                    if (keyPress->code == Keyboard::Key::Left) {
                        if (lr > 0) {
                            bbox.move({ static_cast<float>(width) / -8.f, 0.f });
                            lr--;
                        }
                    }
                    if (keyPress->code == Keyboard::Key::Enter) {
                        if (1) {
                            Vector2f pos = bbox.getPosition();
                            int c = pos.x / (static_cast<float>(width) / 8.f);
                            int r = pos.y / (static_cast<float>(height) / 8.f);

                            if (inside(r, c)) {
                                if (selectedR == -1) {
                                    if (getPlayer(board[r][c]) == currentPlayer) {
                                        selectedR = r;
                                        selectedC = c;
                                    }
                                }
                                else {
                                    if (makeMove(selectedR, selectedC, r, c, currentPlayer)) {
                                        selectedR = -1;
                                        selectedC = -1;
                                        if (ai_mode) {
                                            if (currentPlayer == 1) {
                                                cout << "Player 1 Moves: " << moves1 << endl;
                                                moves1++;
                                                currentPlayer = 2;
                                            }
                                        }
                                        else {
                                            currentPlayer == 1 ? moves1++ : moves2++;
                                            cout << "Player 1 Moves: " << moves1 << "  Player 2 Moves: " << moves2 << endl;
                                            currentPlayer == 1 ? currentPlayer = 2 : currentPlayer = 1;
                                        }
                                    }
                                    else if (getPlayer(board[r][c]) == currentPlayer) {
                                        selectedR = r;
                                        selectedC = c;
                                    }
                                    else {
                                        selectedR = -1;
                                        selectedC = -1;
                                    }
                                }
                            }
                        }
                    }
                }

                if (gameState == STATE_MAIN_MENU) {
                    if (keyPress->code == Keyboard::Key::Up) {
                        selectedMenuOption = (selectedMenuOption - 1 + 4) % 4;
                    }
                    else if (keyPress->code == Keyboard::Key::Down) {
                        selectedMenuOption = (selectedMenuOption + 1) % 4;
                    }
                    else if (keyPress->code == Keyboard::Key::Enter) {
                        if (selectedMenuOption == 0) {
                            gameState = STATE_MODE;
                            /*initBoard();
                            currentPlayer = 1;
                            selectedR = -1;
                            selectedC = -1;
                            gameState = STATE_PLAYING;*/
                        }
                        else if (selectedMenuOption == 1) {
                            if (loadBoard()) {
                                selectedR = -1;
                                selectedC = -1;
                                gameState = STATE_PLAYING;
                            }
                        }
                        else if (selectedMenuOption == 2) {
                            gameState = STATE_SETTINGS;
                        }
                        else if (selectedMenuOption == 3) {
                            saveBoard();
                            window.close();
                        }
                    }
                }
            }
        }

        if (gameState == STATE_PLAYING) {
            if (currentPlayer == 2 && ai_mode) {
                sleep(milliseconds(100));
                aiMove();
                currentPlayer = 1;
            }

            if (!hasAnyPieces(2) || !hasValidMoves(2)) {
                gameState = STATE_PLAYER_WON;
            }
            else if (!hasAnyPieces(1) || !hasValidMoves(1)) {
                gameState = STATE_PLAYER_LOST;
            }

            window.clear();
            drawBoard(window, static_cast<float>(width) / 8.f, static_cast<float>(height) / 8.f);
            window.draw(bbox);
            window.display();
        }
        else if (gameState == STATE_MAIN_MENU) {
            drawMenu(window, font, width);
        }
        else if (gameState == STATE_SETTINGS) {
            drawSettings(window, font, bbox1, width);
        }
        else if (gameState == STATE_PLAYER_WON || gameState == STATE_PLAYER_LOST) {
            drawEndScreen(window, font, gameState == STATE_PLAYER_WON, (width));
        }
        else if (gameState == STATE_MODE) {
            drawModePage(window, font, bbox3, width);
        }
        else if (gameState == STATE_HSAI) {
            drawHighscoreAi(window, font, width);
        }
        else if (gameState == STATE_HSHUMAN) {
            drawHighscoreHuman(window, font, width);
        }
    }
    return 0;
}
