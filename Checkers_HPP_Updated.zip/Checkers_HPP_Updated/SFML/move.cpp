#include "move.hpp"

bool inside(int r, int c) {
    return r >= 0 && r < SIZE && c >= 0 && c < SIZE;
}

bool isKing(int piece) {
    return piece == 3 || piece == 4;
}

int getPlayer(int piece) {
    if (piece == 1 || piece == 3) return 1;
    if (piece == 2 || piece == 4) return 2;
    return 0;
}

bool isValidMove(int r1, int c1, int r2, int c2, int player) {
    if (!inside(r2, c2) || board[r2][c2] != 0) {
        return false;
    }

    int piece = board[r1][c1];
    if (getPlayer(piece) != player) return false;

    int dr = r2 - r1;
    int dc = c2 - c1;
    int abs_dr = abs(dr);
    int abs_dc = abs(dc);

    if (abs_dr == 1 && abs_dc == 1) {
        if (isKing(piece)) {
            return true;
        }
        if ((player == 1 && dr == -1) || (player == 2 && dr == 1)) {
            return true;
        }
    }

    if (abs_dr == 2 && abs_dc == 2) {
        if (isKing(piece)) {
            int r_mid = r1 + dr / 2;
            int c_mid = c1 + dc / 2;
            int opponent = (player == 1) ? 2 : 1;
            int midPiece = board[r_mid][c_mid];
            if (getPlayer(midPiece) == opponent) {
                return true;
            }
        }
        else {
            if ((player == 1 && dr == -2) || (player == 2 && dr == 2)) {
                int r_mid = r1 + dr / 2;
                int c_mid = c1 + dc / 2;
                int opponent = (player == 1) ? 2 : 1;
                int midPiece = board[r_mid][c_mid];
                if (getPlayer(midPiece) == opponent) {
                    return true;
                }
            }
        }
    }

    return false;
}

bool makeMove(int r1, int c1, int r2, int c2, int player) {
    int piece = board[r1][c1];
    if (getPlayer(piece) == player && isValidMove(r1, c1, r2, c2, player)) {
        board[r2][c2] = piece;
        board[r1][c1] = 0;

        int dr = r2 - r1;
        int dc = c2 - c1;

        if (abs(dr) == 2 && abs(dc) == 2) {
            int r_mid = r1 + dr / 2;
            int c_mid = c1 + dc / 2;
            board[r_mid][c_mid] = 0;
        }

        if (player == 1 && r2 == 0 && piece == 1) {
            board[r2][c2] = 3;
        }
        if (player == 2 && r2 == 7 && piece == 2) {
            board[r2][c2] = 4;
        }

        return true;
    }
    return false;
}

int evaluateMove(int r1, int c1, int r2, int c2) {
    int score = 0;
    int piece = board[r1][c1];

    int dr = r2 - r1;
    int dc = c2 - c1;
    if (abs(dr) == 2 && abs(dc) == 2) {
        score += 100;

        int r_mid = r1 + dr / 2;
        int c_mid = c1 + dc / 2;
        if (isKing(board[r_mid][c_mid])) {
            score += 50;
        }
    }

    if (piece == 2) {
        score += r2;
    }

    if (piece == 2 && r2 == 7) {
        score += 150;
    }

    if (isKing(piece)) {
        int centerDist = abs(r2 - 3) + abs(c2 - 3);
        score += (6 - centerDist) * 5;
    }

    if (!isKing(piece)) {
        if (c2 == 0 || c2 == 7) {
            score -= 10;
        }
    }

    return score;
}

void aiMove() {
    int moveCount = 0;
    int jumpCount = 0;
    int moveScores[MAX_MOVES];

    for (int r = 0; r < SIZE; r++) {
        for (int c = 0; c < SIZE; c++) {
            int piece = board[r][c];
            if (getPlayer(piece) == 2) {
                int directions[4] = { -2, -1, 1, 2 };
                for (int i = 0; i < 4; i++) {
                    int dr = directions[i];
                    for (int j = 0; j < 4; j++) {
                        int dc = directions[j];
                        if (abs(dr) != abs(dc)) continue;
                        int r2 = r + dr;
                        int c2 = c + dc;
                        if (isValidMove(r, c, r2, c2, 2)) {
                            if (abs(dr) == 2 && jumpCount < MAX_MOVES) {
                                jumpMoves[jumpCount][0] = r;
                                jumpMoves[jumpCount][1] = c;
                                jumpMoves[jumpCount][2] = r2;
                                jumpMoves[jumpCount][3] = c2;
                                jumpCount++;
                            }
                            if (moveCount < MAX_MOVES) {
                                moves[moveCount][0] = r;
                                moves[moveCount][1] = c;
                                moves[moveCount][2] = r2;
                                moves[moveCount][3] = c2;
                                moveScores[moveCount] = evaluateMove(r, c, r2, c2);
                                moveCount++;
                            }
                        }
                    }
                }
            }
        }
    }

    if (moveCount == 0) return;

    if (jumpCount > 0) {
        int bestIdx = 0;
        int bestScore = evaluateMove(jumpMoves[0][0], jumpMoves[0][1],
            jumpMoves[0][2], jumpMoves[0][3]);
        for (int i = 1; i < jumpCount; i++) {
            int score = evaluateMove(jumpMoves[i][0], jumpMoves[i][1],
                jumpMoves[i][2], jumpMoves[i][3]);
            if (score > bestScore) {
                bestScore = score;
                bestIdx = i;
            }
        }
        makeMove(jumpMoves[bestIdx][0], jumpMoves[bestIdx][1],
            jumpMoves[bestIdx][2], jumpMoves[bestIdx][3], 2);
    }
    else {
        int bestIdx = 0;
        int bestScore = moveScores[0];
        for (int i = 1; i < moveCount; i++) {
            if (moveScores[i] > bestScore) {
                bestScore = moveScores[i];
                bestIdx = i;
            }
        }
        makeMove(moves[bestIdx][0], moves[bestIdx][1],
            moves[bestIdx][2], moves[bestIdx][3], 2);
    }
}

bool hasValidMoves(int player) {
    for (int r = 0; r < SIZE; r++) {
        for (int c = 0; c < SIZE; c++) {
            int piece = board[r][c];
            if (getPlayer(piece) == player) {
                int directions[4] = { -2, -1, 1, 2 };
                for (int i = 0; i < 4; i++) {
                    int dr = directions[i];
                    for (int j = 0; j < 4; j++) {
                        int dc = directions[j];
                        if (abs(dr) != abs(dc)) continue;
                        int r2 = r + dr;
                        int c2 = c + dc;
                        if (isValidMove(r, c, r2, c2, player)) {
                            return true;
                        }
                    }
                }
            }
        }
    }
    return false;
}

bool hasAnyPieces(int player) {
    for (int r = 0; r < SIZE; r++) {
        for (int c = 0; c < SIZE; c++) {
            if (getPlayer(board[r][c]) == player) {
                return true;
            }
        }
    }
    return false;
}
