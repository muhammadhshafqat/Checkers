#ifndef MOVE_HPP
#define MOVE_HPP

#include <iostream>
#include <SFML/Graphics.hpp>
#include <fstream>
#include <cstdlib>
#include <ctime>
#include "draw.hpp"
#include "save.hpp"

using namespace std;
using namespace sf;

bool inside(int r, int c);

bool isKing(int piece);

int getPlayer(int piece);

bool isValidMove(int r1, int c1, int r2, int c2, int player);

bool makeMove(int r1, int c1, int r2, int c2, int player);

int evaluateMove(int r1, int c1, int r2, int c2);

void aiMove();

bool hasValidMoves(int player);

bool hasAnyPieces(int player);



#endif // !MOVE_HPP
