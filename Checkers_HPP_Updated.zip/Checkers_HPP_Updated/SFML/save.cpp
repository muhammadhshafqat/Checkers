#include "save.hpp"

void swap(int arr[], int i, int j) {
    arr[i] = arr[i] + arr[j];
    arr[j] = arr[i] - arr[j];
    arr[i] = arr[i] - arr[j];
}

void sort(int array[], int m) {
    for (int i = 0; i < m; i++) {
        int min = array[i];
        int k = i;
        for (int j = i + 1; j < m; j++) {
            if (array[j] < array[i]) {
                min = array[j];
                k = j;
            }
            if (k != i) {
                swap(array, i, k);
            }
        }
    }
}

void initBoard() {
    for (int r = 0; r < SIZE; r++) {
        for (int c = 0; c < SIZE; c++) board[r][c] = 0;
    }
    for (int r = 0; r < 3; r++)
        for (int c = 0; c < SIZE; c++)
            if ((r + c) % 2 == 1) board[r][c] = 2;
    for (int r = 5; r < SIZE; r++)
        for (int c = 0; c < SIZE; c++)
            if ((r + c) % 2 == 1) board[r][c] = 1;
    ifstream f("hs1_count.txt");
    f >> hs1_count;
    f.close();
    ifstream g("hs2_count.txt");
    g >> hs2_count;
    g.close();
}

void saveBoard() {
    ofstream f("save.txt");
    ofstream t("theme.txt");
    ofstream trn("turn1.txt");
    ofstream mode("mode.txt");
    ofstream mvs1("moves1.txt");
    ofstream mvs2("moves2.txt");
    trn << currentPlayer;
    t << darkTheme << "\n";
    mode << ai_mode;
    mvs1 << moves1;
    mvs2 << moves2;
    for (int r = 0; r < SIZE; r++) {
        for (int c = 0; c < SIZE; c++) f << board[r][c] << " ";
        f << "\n";
    }
    f.close();
    t.close();
    trn.close();
    mode.close();
    mvs1.close();
    mvs2.close();
}

bool loadBoard() {
    ifstream f("save.txt");
    ifstream t("theme.txt");
    ifstream trn("turn1.txt");
    ifstream mode("mode.txt");
    ifstream mvs1("moves1.txt");
    ifstream mvs2("moves2.txt");
    trn >> currentPlayer;
    if (!f.is_open()) return false;
    t >> darkTheme;
    mode >> ai_mode;
    mvs1 >> moves1;
    mvs2 >> moves2;
    for (int r = 0; r < SIZE; r++)
        for (int c = 0; c < SIZE; c++) f >> board[r][c];
    f.close();
    t.close();
    trn.close();
    mode.close();
    mvs1.close();
    mvs2.close();
    return true;
}

void saveHighscores(bool playerWon) {
    cout << "Highscores Saved" << endl;
    if (ai_mode) {
        if (playerWon) {
            fstream hs("hs_ai.txt", ios::app | ios::in);
            fstream hsc("hsai_count.txt");
            hsc >> hsai_count;
            cout << hsai_count;
            if (hsai_count < 5) {
                hs << moves1 << endl;
                cout << "moves: " << moves1;
                hsai_count++;
                hsc.seekg(0, ios::beg);
                hsc << hsai_count;
                int hs1c[5] = {};
                hs.seekg(0, ios::beg);
                for (int i = 0; i < hsai_count; i++) {
                    hs >> hs1c[i];
                }
                sort(hs1c, hs1_count);
                hs.close();
                ofstream hsai1("hs_ai.txt");
                for (int j = 0; j < hsai_count; j++) {
                    hsai1 << hs1c[j] << endl;
                }
            }
            else {
                int hs1[6] = {};
                for (int i = 0; i < 5; i++) {
                    hs >> hs1[i];
                }
                hs1[5] = moves1;
                sort(hs1, 6);
                for (int j = 0; j < 5; j++) {
                    hs << hs1[j] << endl;
                }
                hsai_count = 5;
                hsc.seekg(0, ios::beg);
                hsc << hsai_count;
            }
            hs.close();
            hsc.close();
        }
    }
    else {
        fstream hs1("hs1.txt", ios::app | ios::in);
        fstream hs2("hs2.txt", ios::app | ios::in);
        fstream hs1_c("hs1_count.txt");
        fstream hs2_c("hs2_count.txt");
        if (hs1.is_open() && hs2.is_open() && hs1_c.is_open() && hs2_c.is_open()) {
            hs1_c.seekg(0, ios::beg);
            hs2_c.seekg(0, ios::beg);
            hs1_c >> hs1_count;
            hs2_c >> hs2_count;
            cout << hs1_count << "  " << hs2_count << endl;
            if (playerWon) {
                if (hs1_count < 5) {
                    hs1 << moves1 << endl;
                    hs1_count++;
                    cout << hs1_count << "  " << moves1 << endl;
                    hs1_c.seekg(0, ios::beg);
                    hs1_c << hs1_count;
                    int hs1c[5] = {};
                    hs1.seekg(0, ios::beg);
                    for (int i = 0; i < hs1_count; i++) {
                        hs1 >> hs1c[i];
                    }
                    sort(hs1c, hs1_count);
                    hs1.close();
                    ofstream hs1_2("hs1.txt");
                    hs1.seekp(0, ios::beg);
                    for (int j = 0; j < hs1_count; j++) {
                        hs1_2 << hs1c[j] << endl;
                    }
                }
                else {
                    int hs1c[6] = {};
                    hs1.seekg(0, ios::beg);
                    for (int i = 0; i < 5; i++) {
                        hs1 >> hs1c[i];
                    }
                    hs1c[5] = moves1;
                    sort(hs1c, 6);
                    hs1.close();
                    ofstream hs1("hs1.txt");
                    hs1.seekp(0, ios::beg);
                    for (int j = 0; j < 5; j++) {
                        hs1 << hs1c[j] << endl;
                    }
                    hs1_count = 5;
                    hs1_c.seekg(0, ios::beg);
                    hs1_c << hs1_count;
                }
            }
            else if (hs2_count < 5) {
                hs2 << moves2 << endl;
                hs2_count++;
                cout << hs1_count << "  " << moves1 << endl;
                hs2_c.seekg(0, ios::beg);
                hs2_c << hs2_count;
                int hs2c[5] = {};
                hs2.seekg(0, ios::beg);
                for (int i = 0; i < hs2_count; i++) {
                    hs2 >> hs2c[i];
                }
                sort(hs2c, hs2_count);
                hs2.close();
                ofstream hs2_2("hs2.txt");
                hs2.seekp(0, ios::beg);
                for (int j = 0; j < hs2_count; j++) {
                    hs2_2 << hs2c[j] << endl;
                }
            }
            else {
                int hs2c[6] = {};
                hs2.seekg(0, ios::beg);
                for (int i = 0; i < 5; i++) {
                    hs2 >> hs2c[i];
                }
                hs2c[5] = moves2;
                sort(hs2c, 6);
                hs2.close();
                ofstream hs2("hs2.txt");
                hs2.seekp(0, ios::beg);
                for (int j = 0; j < 5; j++) {
                    hs2 << hs2c[j] << endl;
                }
                hs2_count = 5;
                hs2_c.seekg(0, ios::beg);
                hs2_c << hs2_count;
            }
        hs1.close();
        hs2.close();
        hs2_c.close();
        hs1_c.close();
        }
        else {
            cout << "Error";
        }
    }
}
