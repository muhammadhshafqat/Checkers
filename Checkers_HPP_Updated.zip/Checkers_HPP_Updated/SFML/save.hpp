#ifndef SAVE_HPP
#define SAVE_HPP

#include <iostream>
#include <SFML/Graphics.hpp>
#include <fstream>
#include <cstdlib>
#include <ctime>
#include "move.hpp"
#include "draw.hpp"

using namespace std;
using namespace sf;

void swap(int arr[], int i, int j);

void sort(int array[], int m);

void initBoard();

void saveBoard();

bool loadBoard();

void saveHighscores(bool playerWon);


#endif // !SAVE_HPP
