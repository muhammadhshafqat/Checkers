﻿#include <iostream>
#include <SFML/Graphics.hpp>
#include <fstream>
#include <cstdlib>
#include <ctime>
#include <SFML/Audio.hpp>

using namespace std;
using namespace sf;
const int SIZE = 8;
const int CELL_SIZE = 60;
const int WINDOW_SIZE = (SIZE * CELL_SIZE);
const int MAX_MOVES = 100;

// Game states
const int STATE_MAIN_MENU = 0;
const int STATE_PLAYING = 1;
const int STATE_PLAYER_WON = 2;
const int STATE_PLAYER_LOST = 3;
const int STATE_SETTINGS = 4;
const int STATE_MODE = 5;
const int STATE_HSAI = 6;
const int STATE_HSHUMAN = 7;

// Theme colors
bool darkTheme = false;
bool ai_mode = false;
bool hsdisped = false;
Color lightBoardColor1(240, 217, 181);
Color lightBoardColor2(181, 136, 99);
Color darkBoardColor1(60, 70, 80);
Color darkBoardColor2(30, 40, 50);
Color black_trans(0, 0, 0, 0);
Color black(0, 0, 0);

int board[SIZE][SIZE];
int selectedR = -1, selectedC = -1;
int currentPlayer = 1;
int gameState = STATE_MAIN_MENU;
int selectedMenuOption = 0;
int moves1 = 0;
int moves2 = 0;
int hs1_count = 0;
int hs2_count = 0;
int hsai_count = 0;

// Move storage: [moveIndex][0=r1, 1=c1, 2=r2, 3=c2]
int moves[MAX_MOVES][4];
int jumpMoves[MAX_MOVES][4];

void swap(int arr[], int i, int j) {
    arr[i] = arr[i] + arr[j];
    arr[j] = arr[i] - arr[j];
    arr[i] = arr[i] - arr[j];
}

void sort(int array[], int m) {
    for (int i = 0; i < m; i++) {
        int min = array[i];
        int k = i;
        for (int j = i + 1; j < m; j++) {
            if (array[j] < array[i]) {
                min = array[j];
                k = j;
            }
            if (k != i) {
                swap(array, i, k);
            }
        }
    }
}

void initBoard() {
    for (int r = 0; r < SIZE; r++) {
        for (int c = 0; c < SIZE; c++) board[r][c] = 0;
    }
    for (int r = 0; r < 3; r++)
        for (int c = 0; c < SIZE; c++)
            if ((r + c) % 2 == 1) board[r][c] = 2;
    for (int r = 5; r < SIZE; r++)
        for (int c = 0; c < SIZE; c++)
            if ((r + c) % 2 == 1) board[r][c] = 1;
    ifstream f("hs1_count.txt");
    f >> hs1_count;
    f.close();
    ifstream g("hs2_count.txt");
    g >> hs2_count;
    g.close();
}

void saveBoard() {
    ofstream f("save.txt");
    ofstream t("theme.txt");
    ofstream trn("turn1.txt");
    ofstream mode("mode.txt");
    ofstream mvs1("moves1.txt");
    ofstream mvs2("moves2.txt");
    trn << currentPlayer;
    t << darkTheme << "\n";
    mode << ai_mode;
    mvs1 << moves1;
    mvs2 << moves2;
    for (int r = 0; r < SIZE; r++) {
        for (int c = 0; c < SIZE; c++) f << board[r][c] << " ";
        f << "\n";
    }
    f.close();
    t.close();
    trn.close();
    mode.close();
    mvs1.close();
    mvs2.close();
}

bool loadBoard() {
    ifstream f("save.txt");
    ifstream t("theme.txt");
    ifstream trn("turn1.txt");
    ifstream mode("mode.txt");
    ifstream mvs1("moves1.txt");
    ifstream mvs2("moves2.txt");
    trn >> currentPlayer;
    if (!f.is_open()) return false;
    t >> darkTheme;
    mode >> ai_mode;
    mvs1 >> moves1;
    mvs2 >> moves2;
    for (int r = 0; r < SIZE; r++)
        for (int c = 0; c < SIZE; c++) f >> board[r][c];
    f.close();
    t.close();
    trn.close();
    mode.close();
    mvs1.close();
    mvs2.close();
    return true;
}

void saveHighscores() {
    cout << "Highscores Saved" << endl;
    if (ai_mode) {
        fstream hs("hs_ai.txt", ios::app | ios::in);
        fstream hsc("hsai_count.txt");
        hsc >> hsai_count;
        cout << hsai_count;
        if (hsai_count < 5) {
            hs << moves1 << endl;
            hsai_count++;
            hsc << hsai_count;
            int hs1c[5] = {};
            for (int i = 0; i < hsai_count; i++) {
                hs >> hs1c[i];
            }
            sort(hs1c, hs1_count);
            hs.close();
            ofstream hs("hs_ai.txt");
            for (int j = 0; j < hsai_count; j++) {
                hs << hs1c[j] << endl;
            }
        }
        else {
            int hs1[6] = {};
            for (int i = 0; i < 5; i++) {
                hs >> hs1[i];
            }
            hs1[5] = moves1;
            sort(hs1, 6);
            for (int j = 0; j < 5; j++) {
                hs << hs1[j] << endl;
            }
            hsai_count = 5;
            hsc << hsai_count;
        }
        hs.close();
        hsc.close();
    }
    else {
        fstream hs1("hs1.txt", ios::app | ios::in);
        fstream hs2("hs2.txt", ios::app | ios::in);
        fstream hs1_c("hs1_count.txt");
        fstream hs2_c("hs2_count.txt");
        if (hs1.is_open() && hs2.is_open() && hs1_c.is_open() && hs2_c.is_open()) {
            hs1_c.seekg(0, ios::beg);
            hs2_c.seekg(0, ios::beg);
            hs1_c >> hs1_count;
            hs2_c >> hs2_count;
            cout << hs1_count << "  " << hs2_count << endl;
            if (hs1_count < 5) {
                hs1 << moves1 << endl;
                hs1_count++;
                cout << hs1_count << "  " << moves1 << endl;
                hs1_c.seekp(0, ios::beg);
                hs1_c << hs1_count;
                int hs1c[5] = {};
                hs1.seekg(0, ios::beg);
                for (int i = 0; i < hs1_count; i++) {
                    hs1 >> hs1c[i];
                }
                sort(hs1c, hs1_count);
                hs1.close();
                ofstream hs1("hs1.txt");
                hs1.seekp(0, ios::beg);
                for (int j = 0; j < hs1_count; j++) {
                    hs1 << hs1c[j] << endl;
                }
            }
            else {
                int hs1c[6] = {};
                hs1.seekg(0, ios::beg);
                for (int i = 0; i < 5; i++) {
                    hs1 >> hs1c[i];
                }
                hs1c[5] = moves1;
                sort(hs1c, 6);
                hs1.close();
                ofstream hs1("hs1.txt");
                hs1.seekp(0, ios::beg);
                for (int j = 0; j < 5; j++) {
                    hs1 << hs1c[j] << endl;
                }
                hs1_count = 5;
                hs1_c.seekp(0, ios::beg);
                hs1_c << hs1_count;
            }
            if (hs2_count < 5) {
                hs2 << moves2 << endl;
                hs2_count++;
                cout << hs1_count << "  " << moves1 << endl;
                hs2_c.seekp(0, ios::beg);
                hs2_c << hs1_count;
                int hs2c[5] = {};
                hs2.seekg(0, ios::beg);
                for (int i = 0; i < hs2_count; i++) {
                    hs1 >> hs2c[i];
                }
                sort(hs2c, hs1_count);
                hs2.close();
                ofstream hs2("hs2.txt");
                hs2.seekp(0, ios::beg);
                for (int j = 0; j < hs2_count; j++) {
                    hs1 << hs2c[j] << endl;
                }
            }
            else {
                int hs2c[6] = {};
                hs2.seekg(0, ios::beg);
                for (int i = 0; i < 5; i++) {
                    hs1 >> hs2c[i];
                }
                hs2c[5] = moves2;
                sort(hs2c, 6);
                hs2.close();
                ofstream hs2("hs2.txt");
                hs2.seekp(0, ios::beg);
                for (int j = 0; j < 5; j++) {
                    hs1 << hs2c[j] << endl;
                }
                hs2_count = 5;
                hs2_c.seekp(0, ios::beg);
                hs2_c << hs1_count;
            }
            hs1.close();
            hs2.close();
            hs2_c.close();
            hs1_c.close();
        }
        else {
            cout << "Error";
        }
    }
}

bool inside(int r, int c) {
    return r >= 0 && r < SIZE && c >= 0 && c < SIZE;
}

bool isKing(int piece) {
    return piece == 3 || piece == 4;
}

int getPlayer(int piece) {
    if (piece == 1 || piece == 3) return 1;
    if (piece == 2 || piece == 4) return 2;
    return 0;
}

bool isValidMove(int r1, int c1, int r2, int c2, int player) {
    if (!inside(r2, c2) || board[r2][c2] != 0) {
        return false;
    }

    int piece = board[r1][c1];
    if (getPlayer(piece) != player) return false;

    int dr = r2 - r1;
    int dc = c2 - c1;
    int abs_dr = abs(dr);
    int abs_dc = abs(dc);

    if (abs_dr == 1 && abs_dc == 1) {
        if (isKing(piece)) {
            return true;
        }
        if ((player == 1 && dr == -1) || (player == 2 && dr == 1)) {
            return true;
        }
    }

    if (abs_dr == 2 && abs_dc == 2) {
        if (isKing(piece)) {
            int r_mid = r1 + dr / 2;
            int c_mid = c1 + dc / 2;
            int opponent = (player == 1) ? 2 : 1;
            int midPiece = board[r_mid][c_mid];
            if (getPlayer(midPiece) == opponent) {
                return true;
            }
        }
        else {
            if ((player == 1 && dr == -2) || (player == 2 && dr == 2)) {
                int r_mid = r1 + dr / 2;
                int c_mid = c1 + dc / 2;
                int opponent = (player == 1) ? 2 : 1;
                int midPiece = board[r_mid][c_mid];
                if (getPlayer(midPiece) == opponent) {
                    return true;
                }
            }
        }
    }

    return false;
}

bool makeMove(int r1, int c1, int r2, int c2, int player) {
    int piece = board[r1][c1];
    if (getPlayer(piece) == player && isValidMove(r1, c1, r2, c2, player)) {
        board[r2][c2] = piece;
        board[r1][c1] = 0;

        int dr = r2 - r1;
        int dc = c2 - c1;

        if (abs(dr) == 2 && abs(dc) == 2) {
            int r_mid = r1 + dr / 2;
            int c_mid = c1 + dc / 2;
            board[r_mid][c_mid] = 0;
        }

        if (player == 1 && r2 == 0 && piece == 1) {
            board[r2][c2] = 3;
        }
        if (player == 2 && r2 == 7 && piece == 2) {
            board[r2][c2] = 4;
        }

        return true;
    }
    return false;
}

int evaluateMove(int r1, int c1, int r2, int c2) {
    int score = 0;
    int piece = board[r1][c1];

    int dr = r2 - r1;
    int dc = c2 - c1;
    if (abs(dr) == 2 && abs(dc) == 2) {
        score += 100;

        int r_mid = r1 + dr / 2;
        int c_mid = c1 + dc / 2;
        if (isKing(board[r_mid][c_mid])) {
            score += 50;
        }
    }

    if (piece == 2) {
        score += r2;
    }

    if (piece == 2 && r2 == 7) {
        score += 150;
    }

    if (isKing(piece)) {
        int centerDist = abs(r2 - 3) + abs(c2 - 3);
        score += (6 - centerDist) * 5;
    }

    if (!isKing(piece)) {
        if (c2 == 0 || c2 == 7) {
            score -= 10;
        }
    }

    return score;
}

void aiMove() {
    int moveCount = 0;
    int jumpCount = 0;
    int moveScores[MAX_MOVES];

    for (int r = 0; r < SIZE; r++) {
        for (int c = 0; c < SIZE; c++) {
            int piece = board[r][c];
            if (getPlayer(piece) == 2) {
                int directions[4] = { -2, -1, 1, 2 };
                for (int i = 0; i < 4; i++) {
                    int dr = directions[i];
                    for (int j = 0; j < 4; j++) {
                        int dc = directions[j];
                        if (abs(dr) != abs(dc)) continue;
                        int r2 = r + dr;
                        int c2 = c + dc;
                        if (isValidMove(r, c, r2, c2, 2)) {
                            if (abs(dr) == 2 && jumpCount < MAX_MOVES) {
                                jumpMoves[jumpCount][0] = r;
                                jumpMoves[jumpCount][1] = c;
                                jumpMoves[jumpCount][2] = r2;
                                jumpMoves[jumpCount][3] = c2;
                                jumpCount++;
                            }
                            if (moveCount < MAX_MOVES) {
                                moves[moveCount][0] = r;
                                moves[moveCount][1] = c;
                                moves[moveCount][2] = r2;
                                moves[moveCount][3] = c2;
                                moveScores[moveCount] = evaluateMove(r, c, r2, c2);
                                moveCount++;
                            }
                        }
                    }
                }
            }
        }
    }

    if (moveCount == 0) return;

    if (jumpCount > 0) {
        int bestIdx = 0;
        int bestScore = evaluateMove(jumpMoves[0][0], jumpMoves[0][1],
            jumpMoves[0][2], jumpMoves[0][3]);
        for (int i = 1; i < jumpCount; i++) {
            int score = evaluateMove(jumpMoves[i][0], jumpMoves[i][1],
                jumpMoves[i][2], jumpMoves[i][3]);
            if (score > bestScore) {
                bestScore = score;
                bestIdx = i;
            }
        }
        makeMove(jumpMoves[bestIdx][0], jumpMoves[bestIdx][1],
            jumpMoves[bestIdx][2], jumpMoves[bestIdx][3], 2);
    }
    else {
        int bestIdx = 0;
        int bestScore = moveScores[0];
        for (int i = 1; i < moveCount; i++) {
            if (moveScores[i] > bestScore) {
                bestScore = moveScores[i];
                bestIdx = i;
            }
        }
        makeMove(moves[bestIdx][0], moves[bestIdx][1],
            moves[bestIdx][2], moves[bestIdx][3], 2);
    }
}

bool hasValidMoves(int player) {
    for (int r = 0; r < SIZE; r++) {
        for (int c = 0; c < SIZE; c++) {
            int piece = board[r][c];
            if (getPlayer(piece) == player) {
                int directions[4] = { -2, -1, 1, 2 };
                for (int i = 0; i < 4; i++) {
                    int dr = directions[i];
                    for (int j = 0; j < 4; j++) {
                        int dc = directions[j];
                        if (abs(dr) != abs(dc)) continue;
                        int r2 = r + dr;
                        int c2 = c + dc;
                        if (isValidMove(r, c, r2, c2, player)) {
                            return true;
                        }
                    }
                }
            }
        }
    }
    return false;
}

bool hasAnyPieces(int player) {
    for (int r = 0; r < SIZE; r++) {
        for (int c = 0; c < SIZE; c++) {
            if (getPlayer(board[r][c]) == player) {
                return true;
            }
        }
    }
    return false;
}

void drawBoard(RenderWindow& window, float width, float height) {
    RectangleShape cell(Vector2f(width, height));
    Texture crownTexture;
    crownTexture.loadFromFile("C:/Users/Administrator/source/repos/PF_PROJECT/PF_PROJECT/kingcrown.png");
    Texture crownTexture2;
    crownTexture2.loadFromFile("C:/Users/Administrator/source/repos/PF_PROJECT/PF_PROJECT/kingcrown2.png");

    Color color1 = darkTheme ? darkBoardColor1 : lightBoardColor1;
    Color color2 = darkTheme ? darkBoardColor2 : lightBoardColor2;

    for (int r = 0; r < SIZE; r++) {
        for (int c = 0; c < SIZE; c++) {
            if ((r + c) % 2 == 0)
                cell.setFillColor(color1);
            else
                cell.setFillColor(color2);

            cell.setPosition(Vector2f((c * width), (r * height)));
            window.draw(cell);
        }
    }

    if (selectedR != -1 && selectedC != -1) {
        RectangleShape highlight(Vector2f(width, height));
        highlight.setPosition(Vector2f(static_cast<float>(selectedC * width), static_cast<float>(selectedR * height)));
        highlight.setFillColor(Color(255, 255, 0, 100));
        window.draw(highlight);
        int flag2 = 1;
        int directions[4] = { -2, -1, 1, 2 };
        for (int i = 0; i < 4; i++) {
            int dr = directions[i];
            for (int j = 0; j < 4; j++) {
                int dc = directions[j];
                if (abs(dr) != abs(dc)) continue;
                int r2 = selectedR + dr;
                int c2 = selectedC + dc;

                if (isValidMove(selectedR, selectedC, r2, c2, currentPlayer)) {
                    CircleShape dot(9.f);
                    dot.setFillColor(Color(50, 205, 50, 180));
                    dot.setPosition(Vector2f(
                        static_cast<float>(c2 * width + width / 2 - 8),
                        static_cast<float>(r2 * height + height / 2 - 8)
                    ));
                    window.draw(dot);
                }
            }
        }
    }
    float rad;
    if (width > height) {
        rad = height * 0.35f;
    }
    else
        rad = width * 0.35f;
    CircleShape piece(rad);
    piece.setOutlineThickness(2.5f);
    piece.setOutlineColor(Color(50, 50, 50)); 


    for (int r = 0; r < SIZE; r++) {
        for (int c = 0; c < SIZE; c++) {
            int p = board[r][c];
            if (p == 1 || p == 3) {
                piece.setFillColor(Color(194, 24, 7));
                piece.setPosition(Vector2f(
                    static_cast<float>(c * width) + ((width - (2.f * rad)) / 2.f),
                    static_cast<float>(r * height) + ((height - (2.f * rad)) / 2.f)
                ));
                window.draw(piece);

                if (p == 3) {
                    Sprite crown(crownTexture);
                    float targetSize = width * 0.6f;
                    Vector2u texSize = crownTexture.getSize();
                    float scale = targetSize / texSize.x;
                    crown.setScale(sf::Vector2f(scale, scale));
                    crown.setPosition(Vector2f(static_cast<float>(c * width) + width * 0.2f,
                                               static_cast<float>(r * height) + height * 0.2f));
                    window.draw(crown);
                }
            }
            else if (p == 2 || p == 4) {
                piece.setFillColor(Color(0, 0, 0));
                piece.setPosition(Vector2f(
                    static_cast<float>(c * width) + ((width - (2.f * rad)) / 2.f),
                    static_cast<float>(r * height) + ((height - (2.f * rad)) / 2.f)
                ));
                window.draw(piece);

                if (p == 4) {
                    sf::Sprite crown2(crownTexture2);
                    float targetSize = width * 0.6f;
                    Vector2u texSize = crownTexture2.getSize();
                    float scale = targetSize / texSize.x;
                    crown2.setScale(sf::Vector2f(scale, scale));
                    crown2.setPosition(Vector2f(static_cast<float>(c * width) + width * 0.2f,
                        static_cast<float>(r * height) + height * 0.2f));
                    // Draw
                    window.draw(crown2);
                }
            }
        }
    }
}

void drawMenu(RenderWindow& window, Font& font, float windowSize) {
    float ratiox = static_cast<float>(window.getSize().x) / 480.f;
    float ratioy = static_cast<float>(window.getSize().y) / 480.f;
    Color bgColor = darkTheme ? Color(181, 136, 99) : Color(240, 217, 181);
    window.clear(bgColor);

    Text title(font);
    title.setString("CHECKERS");
    title.setCharacterSize(70 * (ratiox < ratioy ? ratiox : ratioy));
    title.setFillColor(darkTheme ? Color(240, 217, 181) : Color(181, 136, 99));
    title.setStyle(Text::Bold);
    FloatRect titleBounds = title.getLocalBounds();
    title.setPosition(Vector2f(windowSize / 2.f - titleBounds.size.x / 2.f, 40.f * ratioy));
    window.draw(title);

    const char* options[4] = { "New Game", "Continue", "Settings", "Quit"};
    for (int i = 0; i < 4; i++) {
        RectangleShape button(Vector2f(280.f * ratiox, 50.f * ratioy));
        button.setPosition(Vector2f(windowSize / 2.f - (140.f * ratiox), (160.f + i * 70.f) * ratioy));

        if (i == selectedMenuOption) {
            button.setFillColor(darkTheme ? Color(240, 217, 181) : Color(181, 136, 99)); // selected button is lighter
        }
        else {
            button.setFillColor(darkTheme ? Color(181, 136, 99) : Color(240, 217, 181)); // unselected button is darker
        }
        window.draw(button);

        Text optionText(font);
        optionText.setString(options[i]);
        optionText.setCharacterSize(24 * (ratiox < ratioy ? ratiox : ratioy));
        optionText.setFillColor(i == selectedMenuOption
            ? (darkTheme ? Color(181, 136, 99) : Color(240, 217, 181))  // text opposite to button
            : (darkTheme ? Color(240, 217, 181) : Color(181, 136, 99))
        );
        FloatRect textBounds = optionText.getLocalBounds();
        optionText.setPosition(Vector2f(
            windowSize / 2.f - textBounds.size.x / 2.f,
            (168.f + i * 70.f) * ratioy
        ));
        window.draw(optionText);
    }
    window.display();
}

void drawSettings(RenderWindow& window, Font& font, RectangleShape& bbox1, float windowSize) {
    float ratiox = static_cast<float>(window.getSize().x) / 480.f;
    float ratioy = static_cast<float>(window.getSize().y) / 480.f;
    Color bgColor = darkTheme ? Color(181, 136, 99) : Color(240, 217, 181);
    window.clear(bgColor);

    Text title(font);
    title.setString("SETTINGS");
    title.setCharacterSize(50 * (ratiox < ratioy ? ratiox : ratioy));
    title.setFillColor(darkTheme ? Color(240, 217, 181) : Color(181, 136, 99));
    title.setStyle(Text::Bold);
    FloatRect titleBounds = title.getLocalBounds();
    title.setPosition(Vector2f(windowSize / 2.f - titleBounds.size.x / 2.f, 60.f * ratioy));
    window.draw(title);

    Text themeLabel(font);
    themeLabel.setString("Theme:");
    themeLabel.setCharacterSize(24 * (ratiox < ratioy ? ratiox : ratioy));
    themeLabel.setFillColor(darkTheme ? Color(240, 217, 181) : Color(181, 136, 99));
    themeLabel.setPosition(Vector2f(80.f * ratiox, 180.f * ratioy));
    window.draw(themeLabel);

    RectangleShape lightButton(Vector2f(120.f * ratiox, 45.f * ratioy));
    lightButton.setPosition(Vector2f(100.f * ratiox, 230.f * ratioy));
    lightButton.setFillColor(darkTheme ? Color(240, 217, 181) : Color(181, 136, 99));
    lightButton.setOutlineThickness(2.f);
    lightButton.setOutlineColor(Color(0, 0, 0));
    window.draw(lightButton);

    Text lightText(font);
    lightText.setString("Light");
    lightText.setCharacterSize(20 * (ratiox < ratioy ? ratiox : ratioy));
    lightText.setFillColor(darkTheme ? Color(25, 25, 35) : Color(50, 50, 70));
    FloatRect lightBounds = lightText.getLocalBounds();
    lightText.setPosition(Vector2f(160.f * ratiox - lightBounds.size.x / 2.f, 240.f * ratioy));
    window.draw(lightText);

    RectangleShape darkButton(Vector2f(120.f * ratiox, 45.f * ratioy));
    darkButton.setPosition(Vector2f(260.f * ratiox, 230.f * ratioy));
    darkButton.setFillColor(darkTheme ? Color(181, 136, 99) : Color(240, 217, 181));
    darkButton.setOutlineThickness(2.f);
    darkButton.setOutlineColor(Color(0,0,0));
    window.draw(darkButton);

    Text darkText(font);
    darkText.setString("Dark");
    darkText.setCharacterSize(20 * (ratiox < ratioy ? ratiox : ratioy));
    darkText.setFillColor(darkTheme ? Color(25, 25, 35) : Color(50, 50, 70));
    FloatRect darkBounds = darkText.getLocalBounds();
    darkText.setPosition(Vector2f(320.f * ratiox - darkBounds.size.x / 2.f, 240.f * ratioy));
    window.draw(darkText);

    Text modeLabel(font);
    modeLabel.setString("Leaderboard:");
    modeLabel.setCharacterSize(24 * (ratiox < ratioy ? ratiox : ratioy));
    modeLabel.setFillColor(darkTheme ? Color(240, 217, 181) : Color(181, 136, 99));
    modeLabel.setPosition(Vector2f(80.f * ratiox, 300.f * ratioy));
    window.draw(modeLabel);

    RectangleShape ai(Vector2f(120.f * ratiox, 45.f * ratioy));
    ai.setPosition(Vector2f(100.f * ratiox, 350.f * ratioy));
    ai.setFillColor(!ai_mode ? (darkTheme ? Color(181, 136, 99) : Color(240, 217, 181))
        : (darkTheme ? Color(240, 217, 181) : Color(181, 136, 99)));
    ai.setOutlineThickness(2.f);
    ai.setOutlineColor(Color(0,0,0));
    window.draw(ai);

    Text aiText(font);
    aiText.setString("P1 VS AI");
    aiText.setCharacterSize(20 * (ratiox < ratioy ? ratiox : ratioy));
    aiText.setFillColor(!ai_mode ? (darkTheme ? Color(25, 25, 35) : Color(50, 50, 70))
        : (darkTheme ? Color(25, 25, 35) : Color(50, 50, 70)));
    FloatRect aiBounds = aiText.getLocalBounds();
    aiText.setPosition(Vector2f(160.f * ratiox - aiBounds.size.x / 2.f, 360.f * ratioy));
    window.draw(aiText);

    RectangleShape human(Vector2f(120.f * ratiox, 45.f * ratioy));
    human.setPosition(Vector2f(260.f * ratiox, 350.f * ratioy));
    human.setFillColor(!ai_mode ? (darkTheme ? Color(240, 217, 181) : Color(181, 136, 99))
        : (darkTheme ? Color(181, 136, 99) : Color(240, 217, 181)));
    human.setOutlineThickness(2.f);
    human.setOutlineColor(Color(0,0,0));
    window.draw(human);

    Text humanText(font);
    humanText.setString("P1 VS P2");
    humanText.setCharacterSize(20 * (ratiox < ratioy ? ratiox : ratioy));
    humanText.setFillColor(!ai_mode ? (darkTheme ? Color(25, 25, 35) : Color(50, 50, 70))
        : (darkTheme ? Color(25, 25, 35) : Color(50, 50, 70)));
    FloatRect humanBounds = humanText.getLocalBounds();
    humanText.setPosition(Vector2f(320.f * ratiox - humanBounds.size.x / 2.f, 360.f * ratioy));
    window.draw(humanText);

    Text backText(font);
    backText.setString("Press ESC to go back");
    backText.setCharacterSize(16 * (ratiox < ratioy ? ratiox : ratioy));
    backText.setFillColor(darkTheme ? Color(240, 217, 181) : Color(181, 136, 99));
    FloatRect backBounds = backText.getLocalBounds();
    backText.setPosition(Vector2f(windowSize / 2.f - backBounds.size.x / 2.f, 450.f * ratioy));
    window.draw(backText);

    window.draw(bbox1);
    window.display();
}

void drawModePage(RenderWindow& window, Font& font, RectangleShape& bbox3, float windowSize) {
    float ratiox = static_cast<float>(window.getSize().x) / 480.f;
    float ratioy = static_cast<float>(window.getSize().y) / 480.f;
    Color bgColor = darkTheme ? Color(181, 136, 99) : Color(240, 217, 181);
    window.clear(bgColor);

    Text title(font);
    title.setString("SELECT MODE");
    title.setCharacterSize(50 * (ratiox < ratioy ? ratiox : ratioy));
    title.setFillColor(darkTheme ? Color(240, 217, 181) : Color(181, 136, 99));
    title.setStyle(Text::Bold);
    FloatRect titleBounds = title.getLocalBounds();
    title.setPosition(Vector2f(windowSize / 2.f - titleBounds.size.x / 2.f, 60.f * ratioy));
    window.draw(title);

    RectangleShape aiButton(Vector2f(120.f * ratiox, 45.f * ratioy));
    aiButton.setPosition(Vector2f(100.f * ratiox, 230.f * ratioy));
    aiButton.setFillColor(!ai_mode ? (darkTheme ? Color(181, 136, 99) : Color(240, 217, 181))
        : (darkTheme ? Color(240, 217, 181) : Color(181, 136, 99)));
    aiButton.setOutlineThickness(2.f);
    aiButton.setOutlineColor(Color(0,0,0));
    window.draw(aiButton);

    Text aiText(font);
    aiText.setString("AI");
    aiText.setCharacterSize(20 * (ratiox < ratioy ? ratiox : ratioy));
    aiText.setFillColor(!ai_mode ? (darkTheme ? Color(25, 25, 35) : Color(50, 50, 70))
        : (darkTheme ? Color(25, 25, 35) : Color(50, 50, 70)));
    FloatRect lightBounds = aiText.getLocalBounds();
    aiText.setPosition(Vector2f(160.f * ratiox - lightBounds.size.x / 2.f, 240.f * ratioy));
    window.draw(aiText);

    RectangleShape humanButton(Vector2f(120.f * ratiox, 45.f * ratioy));
    humanButton.setPosition(Vector2f(260.f * ratiox, 230.f * ratioy));
    humanButton.setFillColor(!ai_mode ? (darkTheme ? Color(240, 217, 181) : Color(181, 136, 99))
        : (darkTheme ? Color(181, 136, 99) : Color(240, 217, 181)));
    humanButton.setOutlineThickness(2.f);
    humanButton.setOutlineColor(Color(0,0,0));
    window.draw(humanButton);

    Text humanText(font);
    humanText.setString("Human");
    humanText.setCharacterSize(20 * (ratiox < ratioy ? ratiox : ratioy));
    humanText.setFillColor(!ai_mode ? (darkTheme ? Color(25, 25, 35) : Color(50, 50, 70))
        : (darkTheme ? Color(25, 25, 35) : Color(50, 50, 70)));
    FloatRect darkBounds = humanText.getLocalBounds();
    humanText.setPosition(Vector2f(320.f * ratiox - darkBounds.size.x / 2.f, 240.f * ratioy));
    window.draw(humanText);

    Text backText(font);
    backText.setString("Press ESC to go back");
    backText.setCharacterSize(16 * (ratiox < ratioy ? ratiox : ratioy));
    backText.setFillColor(darkTheme ? Color(240, 217, 181) : Color(181, 136, 99));
    FloatRect backBounds = backText.getLocalBounds();
    backText.setPosition(Vector2f(windowSize / 2.f - backBounds.size.x / 2.f, 450.f * ratioy));
    window.draw(backText);

    window.draw(bbox3);
    window.display();
}

void drawHighscoreHuman(RenderWindow& window, Font& font, float windowSize) {
    int hs1c;
    int hs2c;
    fstream hs1("hs1.txt");
    fstream hs2("hs2.txt");
    fstream hscount1("hs1_count.txt");
    fstream hscount2("hs2_count.txt");
    float ratiox = static_cast<float>(window.getSize().x) / 480.f;
    float ratioy = static_cast<float>(window.getSize().y) / 480.f;
    Color bgColor = darkTheme ? Color(181, 136, 99) : Color(240, 217, 181);
    window.clear(bgColor);

    const char* titleText = "LEADERBOARD [P1 VS P2]";
    Text title(font);
    title.setString(titleText);
    title.setCharacterSize(30 * (ratiox < ratioy ? ratiox : ratioy));
    title.setFillColor(darkTheme ? Color(240, 217, 181) : Color(181, 136, 99));
    title.setStyle(Text::Bold);
    FloatRect resultBounds = title.getLocalBounds();
    title.setPosition(Vector2f(windowSize / 2.f - resultBounds.size.x / 2.f, 20.f * ratioy));
    window.draw(title);

    const char* P1Text = "Player 1";
    Text P1(font);
    P1.setString(P1Text);
    P1.setCharacterSize(25 * (ratiox < ratioy ? ratiox : ratioy));
    P1.setFillColor(darkTheme ? Color(240, 217, 181) : Color(181, 136, 99));
    P1.setStyle(Text::Bold);
    FloatRect P1Bounds = P1.getLocalBounds();
    P1.setPosition(Vector2f((windowSize / 2.f - P1Bounds.size.x / 2.f) / 4.f, 100.f * ratioy - 30.f));
    window.draw(P1);

    const char* P2Text = "Player 2";
    Text P2(font);
    P2.setString(P2Text);
    P2.setCharacterSize(25 * (ratiox < ratioy ? ratiox : ratioy));
    P2.setFillColor(darkTheme ? Color(240, 217, 181) : Color(181, 136, 99));;
    P2.setStyle(Text::Bold);
    FloatRect P2Bounds = P2.getLocalBounds();
    P2.setPosition(Vector2f((windowSize / 2.f - P2Bounds.size.x / 2.f) * 1.75f, 100.f * ratioy - 30.0f));
    window.draw(P2);

    hscount1 >> hs1c;
    hscount2 >> hs2c;
    string c;
    for (int i = 1; i <= hs1c; i++) {
        hs1 >> c;
        Text highscore(font);
        highscore.setString(c);
        highscore.setCharacterSize(15 * (ratiox < ratioy ? ratiox : ratioy));
        highscore.setFillColor(darkTheme ? Color(240, 217, 181) : Color(181, 136, 99));;
        highscore.setStyle(Text::Bold);
        FloatRect resultBounds = highscore.getLocalBounds();
        highscore.setPosition(Vector2f((windowSize / 2.f - resultBounds.size.x / 2.f) / 2.8f, 95.f + (i * 280.f) / 4.f * ratioy));
        window.draw(highscore);
    }

    for (int i = 1; i <= hs2c; i++) {
        hs1 >> c;
        Text highscore(font);
        highscore.setString(c);
        highscore.setCharacterSize(15 * (ratiox < ratioy ? ratiox : ratioy));
        highscore.setFillColor(darkTheme ? Color(240, 217, 181) : Color(181, 136, 99));;
        highscore.setStyle(Text::Bold);
        FloatRect resultBounds = highscore.getLocalBounds();
        highscore.setPosition(Vector2f((windowSize / 2.f - resultBounds.size.x / 2.f) * 1.6f, 95.f + (i * 280.f) / 4.f * ratioy));
        window.draw(highscore);
    }

    hs1.close();
    hs2.close();
    hscount1.close();
    hscount2.close();
    window.display();
}

void drawHighscoreAi(RenderWindow& window, Font& font, float windowSize) {
    int hsc;
    fstream hs("hs_ai.txt");
    fstream hscount("hsai_count.txt");
    float ratiox = static_cast<float>(window.getSize().x) / 480.f;
    float ratioy = static_cast<float>(window.getSize().y) / 480.f;

    Color bgColor = darkTheme ? Color(181, 136, 99) : Color(240, 217, 181);
    window.clear(bgColor);

    const char* titleText = "LEADERBOARD [P1 VS AI]";
    Text title(font);
    title.setString(titleText);
    title.setCharacterSize(30 * (ratiox < ratioy ? ratiox : ratioy));
    title.setFillColor(darkTheme ? Color(240, 217, 181) : Color(181, 136, 99));
    title.setStyle(Text::Bold);
    FloatRect resultBounds = title.getLocalBounds();
    title.setPosition(Vector2f(windowSize / 2.f - resultBounds.size.x / 2.f, 30.f * ratioy));
    window.draw(title);

    hscount >> hsc;
    string c;
    for (int i = 1; i <= hsc; i++) {
        hs >> c;
        Text highscore(font);
        highscore.setString(c);
        highscore.setCharacterSize(15 * (ratiox < ratioy ? ratiox : ratioy));
        highscore.setFillColor(darkTheme ? Color(240, 217, 181) : Color(181, 136, 99));
        highscore.setStyle(Text::Bold);
        FloatRect resultBounds = highscore.getLocalBounds();
        highscore.setPosition(Vector2f(windowSize / 2.f - resultBounds.size.x / 2.f, i * 90.f * ratioy));
        window.draw(highscore);
    }
    hs.close();
    hscount.close();
    window.display();
}

void drawEndScreen(RenderWindow& window, Font& font, bool playerWon, float windowSize) {
    if (!hsdisped) {
        saveHighscores();
        hsdisped = true;
    }

    initBoard();
    saveBoard();

    float ratiox = static_cast<float>(window.getSize().x) / 480.f;
    float ratioy = static_cast<float>(window.getSize().y) / 480.f;

    Color bgColor = darkTheme ? Color(25, 25, 35) : Color(40, 40, 50);
    window.clear(bgColor);

    const char* resultText = ai_mode ? (playerWon ? "YOU WON!" : "YOU LOSE!") : (playerWon ? "PLAYER 1 WON!" : "PLAYER 2 WON!");
    Text result(font);
    result.setString(resultText);
    result.setCharacterSize(50 * (ratiox < ratioy ? ratiox : ratioy));
    result.setFillColor(playerWon ? Color(100, 255, 100) : Color(255, 100, 100));
    result.setStyle(Text::Bold);
    FloatRect resultBounds = result.getLocalBounds();
    result.setPosition(Vector2f(windowSize / 2.f - resultBounds.size.x / 2.f, 120.f * ratioy));
    window.draw(result);

    const char* messageText = ai_mode ? (playerWon ? "Congratulations!" : "Better luck next time!") : (playerWon ? "Congratulations Player 1!" : "Congratulations Player 2!");
    Text message(font);
    message.setString(messageText);
    message.setCharacterSize(30 * (ratiox < ratioy ? ratiox : ratioy));
    message.setFillColor(Color(200, 200, 200));
    FloatRect msgBounds = message.getLocalBounds();
    message.setPosition(Vector2f(windowSize / 2.f - msgBounds.size.x / 2.f, 220.f * ratioy));
    window.draw(message);

    Text playAgain(font);
    playAgain.setString("Click to play again");
    playAgain.setCharacterSize(20 * (ratiox < ratioy ? ratiox : ratioy));
    playAgain.setFillColor(Color(180, 180, 180));
    FloatRect playBounds = playAgain.getLocalBounds();
    playAgain.setPosition(Vector2f(windowSize / 2.f - playBounds.size.x / 2.f, 300.f * ratioy));
    window.draw(playAgain);

    Text menu(font);
    menu.setString("Press ESC for main menu");
    menu.setCharacterSize(16 * (ratiox < ratioy ? ratiox : ratioy));
    menu.setFillColor(Color(160, 160, 160));
    FloatRect menuBounds = menu.getLocalBounds();
    menu.setPosition(Vector2f(windowSize / 2.f - menuBounds.size.x / 2.f, 380.f * ratioy));
    window.draw(menu);

    moves1 = 0;
    moves2 = 0;

    window.display();
}

int main()
{

    srand(static_cast<unsigned>(time(nullptr)));

    RenderWindow window(VideoMode(Vector2u(800, 800)), "Checker Mates", Style::Default);
    window.setFramerateLimit(60);

    auto [width, height] = window.getSize();
    float ratiox = static_cast<float>(width) / 480.f;
    float ratioy = static_cast<float>(height) / 480.f;

    RectangleShape bbox({ static_cast<float>(width) / 8.f , static_cast<float>(height) / 8.f });
    bbox.setPosition({ 0.f, 0.f });
    bbox.setOutlineThickness(-3.f); //-3
    bbox.setFillColor(black_trans);
    bbox.setOutlineColor(black);
    window.draw(bbox);
    int lr = 0, ud = 0;

    RectangleShape bbox1({ 120.f * ratiox, 45.f * ratioy });
    bbox1.setPosition({ 100.f * ratiox, 230.f * ratioy });
    bbox1.setOutlineThickness(4.f);
    bbox1.setFillColor(black_trans);
    bbox1.setOutlineColor(black);
    int lr1 = 0, lr2 = 0, ud1 = 0;

    RectangleShape bbox3({ 120.f * ratiox, 45.f * ratioy });
    bbox3.setPosition({ 100.f * ratiox, 230.f * ratioy });
    bbox3.setOutlineThickness(4.f);
    bbox3.setFillColor(black_trans);
    bbox3.setOutlineColor(black);

    Font font;
    font.openFromFile("C:/Users/Administrator/source/repos/PF_PROJECT/PF_PROJECT/PixelifySans-SemiBold.ttf");
    
    Music backgroundMusic;
    if (!backgroundMusic.openFromFile("C:/Users/Administrator/source/repos/PF_PROJECT/PF_PROJECT/bgmusic.mp3")) {
        cerr << "Failed to load background music!" << endl;
    }
    else {
        backgroundMusic.setLooping(true);
        backgroundMusic.setVolume(35.f);   
        backgroundMusic.play();
    }

    loadBoard();

    while (window.isOpen())
    {
        while (auto event = window.pollEvent())
        {
            if (event->is<Event::Closed>()) {
                saveBoard();
                window.close();
            }
            else if (event->is<Event::Resized>()) {
                auto [widthw, heightw] = window.getSize();
                width = widthw;
                height = heightw;
                float ratiox = static_cast<float>(width) / 480.f;
                float ratioy = static_cast<float>(height) / 480.f;
                auto [w1, h1] = bbox.getSize();
                auto [w2, h2] = bbox1.getSize();
                auto [x2, y2] = bbox1.getPosition();
                auto [x1, y1] = bbox.getPosition();
                int c = static_cast<float>(x1) / static_cast<float>(w1);
                int r = static_cast<float>(y1) / static_cast<float>(h1);
                FloatRect visibleArea({ 0, 0 }, { static_cast<float>(widthw), static_cast<float>(heightw) });
                window.setView(View(visibleArea));
                bbox.setSize(Vector2f(static_cast<float>(width) / 8.f, static_cast<float>(height) / 8.f));
                bbox.setPosition({ static_cast<float>(width * c) / 8.f, static_cast<float>(height * r) / 8.f });
                bbox1.setSize({ 120.f * ratiox, 45.f * ratioy });
                bbox3.setSize({ 120.f * ratiox, 45.f * ratioy });
                bbox1.setPosition({ (!lr1 ? 100.f : 260.f) * ratiox , (!ud1 ? 230.f : 350.f) * ratioy });
                bbox3.setPosition({ (!lr2 ? 100.f : 260.f) * ratiox , 230.f * ratioy });
            }

            if (auto* mousePress = event->getIf<Event::MouseButtonPressed>()) {
                if (mousePress->button == Mouse::Button::Left) {
                    if (gameState == STATE_MAIN_MENU) {
                        // Menu click handling would go here
                    }
                    else if (gameState == STATE_SETTINGS) {
                        float ratiox = static_cast<float>(width) / 480.f;
                        float ratioy = static_cast<float>(height) / 480.f;
                        Vector2i mousePos = Mouse::getPosition(window);
                        if (mousePos.x >= 100 * ratiox && mousePos.x <= 220 * ratiox && mousePos.y >= 230 * ratioy && mousePos.y <= 275 * ratioy) {
                            darkTheme = false;
                        }
                        else if (mousePos.x >= 260 * ratiox && mousePos.x <= 380 * ratiox && mousePos.y >= 230 * ratioy && mousePos.y <= 275 * ratioy) {
                            darkTheme = true;
                        }
                        if (mousePos.x >= 100 * ratiox && mousePos.x <= 220 * ratiox && mousePos.y >= 350 * ratioy && mousePos.y <= 395 * ratioy) {
                            gameState = STATE_HSAI;
                        }
                        else if (mousePos.x >= 260 * ratiox && mousePos.x <= 380 * ratiox && mousePos.y >= 350 * ratioy && mousePos.y <= 395 * ratioy) {
                            gameState = STATE_HSHUMAN;
                        }
                    }
                    else if (gameState == STATE_MODE) {
                        Vector2i mousePos = Mouse::getPosition(window);
                        if (mousePos.x >= 100 * ratiox && mousePos.x <= 220 * ratiox && mousePos.y >= 230 * ratioy && mousePos.y <= 275 * ratioy) {
                            ai_mode = true;
                            initBoard();
                            currentPlayer = 1;
                            selectedR = selectedC = -1;
                            gameState = STATE_PLAYING;
                            moves1 = 0, moves2 = 0;
                        }
                        else if (mousePos.x >= 260 * ratiox && mousePos.x <= 380 * ratiox && mousePos.y >= 230 * ratioy && mousePos.y <= 275 * ratioy) {
                            ai_mode = false;
                            initBoard();
                            currentPlayer = 1;
                            selectedR = selectedC = -1;
                            gameState = STATE_PLAYING;
                            moves1 = 0, moves2 = 0;
                        }
                    }
                    else if (gameState == STATE_PLAYER_WON || gameState == STATE_PLAYER_LOST) {
                        initBoard();
                        lr1 = 0, lr2 = 0, ud1 = 0, lr = 0, ud = 0;
                        currentPlayer = 1;
                        selectedR = -1;
                        selectedC = -1;
                        gameState = STATE_MODE;
                        hsdisped = false;
                    }
                    else if (gameState == STATE_PLAYING) {
                        Vector2i mousePos = Mouse::getPosition(window);
                        int c = mousePos.x / (static_cast<float>(width) / 8.f);
                        int r = mousePos.y / (static_cast<float>(height) / 8.f);
                        bbox.setPosition({ static_cast<float>(width * c) / 8.f, static_cast<float>(height * r) / 8.f });
                        lr = c;
                        ud = r;
                        if (inside(r, c)) {
                            if (selectedR == -1) {
                                if (getPlayer(board[r][c]) == currentPlayer) {
                                    selectedR = r;
                                    selectedC = c;
                                }
                            }
                            else {
                                if (makeMove(selectedR, selectedC, r, c, currentPlayer)) {
                                    selectedR = -1;
                                    selectedC = -1;
                                    if (ai_mode) {
                                        if (currentPlayer == 1) {
                                            cout << "Player 1 Moves: " << moves1 << endl;
                                            moves1++;
                                            currentPlayer = 2;
                                        }
                                    }
                                    else {
                                        currentPlayer == 1 ? moves1++ : moves2++;
                                        cout << "Player 1 Moves: " << moves1 << "  Player 2 Moves: " << moves2 << endl;
                                        currentPlayer == 1 ? currentPlayer = 2 : currentPlayer = 1;
                                    }
                                }
                                else if (getPlayer(board[r][c]) == currentPlayer) {
                                    selectedR = r;
                                    selectedC = c;
                                }
                                else {
                                    selectedR = -1;
                                    selectedC = -1;
                                }
                            }
                        }
                    }
                }
            }

            if (event->is<Event::KeyPressed>()) {
                auto* keyPress = event->getIf<Event::KeyPressed>();

                if (keyPress->code == Keyboard::Key::Escape) {
                    if (gameState == STATE_SETTINGS || gameState == STATE_PLAYER_WON || gameState == STATE_PLAYER_LOST || gameState == STATE_MODE) {
                        gameState = STATE_MAIN_MENU;
                        hsdisped = false;
                    }
                    if (gameState == STATE_HSAI || gameState == STATE_HSHUMAN) {
                        gameState = STATE_SETTINGS;
                    }
                }

                if (gameState == STATE_SETTINGS) {
                    float ratiox = static_cast<float>(width) / 480.f;
                    float ratioy = static_cast<float>(height) / 480.f;
                    if (keyPress->code == Keyboard::Key::Right) {
                        if (lr1 != 1) {
                            bbox1.move({ 160.f * ratiox, 0.f });
                            lr1++;
                        }
                    }
                    if (keyPress->code == Keyboard::Key::Left) {
                        if (lr1 != 0) {
                            bbox1.move({ -160.f * ratiox, 0.f });
                            lr1--;
                        }
                    }
                    if (keyPress->code == Keyboard::Key::Down) {
                        if (ud1 != 1) {
                            bbox1.move({ 0.f, 120.f * ratioy });
                            ud1++;
                        }
                    }
                    if (keyPress->code == Keyboard::Key::Up) {
                        if (ud1 != 0) {
                            bbox1.move({ 0.f, -120.f * ratioy });
                            ud1--;
                        }
                    }
                    if (keyPress->code == Keyboard::Key::Enter) {
                        fstream f("theme.txt", ios::out);
                        f.seekg(0, ios::beg);
                        if (!ud1) {
                            if (!lr1) {
                                darkTheme = false;
                                f << darkTheme;
                            }
                            else {
                                darkTheme = true;
                                f << darkTheme;
                            }
                        }
                        else {
                            if (!lr1) {
                                gameState = STATE_HSAI;
                            }
                            else {
                                gameState = STATE_HSHUMAN;
                            }
                        }
                        f.close();
                    }
                }

                if (gameState == STATE_MODE) {
                    float ratiox = static_cast<float>(width) / 480.f;
                    float ratioy = static_cast<float>(height) / 480.f;
                    if (keyPress->code == Keyboard::Key::Right) {
                        if (lr2 != 1) {
                            bbox3.move({ 160.f * ratiox, 0.f });
                            lr2++;
                        }
                    }
                    if (keyPress->code == Keyboard::Key::Left) {
                        if (lr2 != 0) {
                            bbox3.move({ -160.f * ratiox, 0.f });
                            lr2--;
                        }
                    }
                    if (keyPress->code == Keyboard::Key::Enter) {
                        fstream f("mode.txt", ios::out);
                        f.seekg(0, ios::beg);
                        if (!lr2) {
                            ai_mode = true;
                            f << ai_mode;
                            initBoard();
                            currentPlayer = 1;
                            selectedR = selectedC = -1;
                            gameState = STATE_PLAYING;
                            moves1 = 0;
                            moves2 = 0;
                        }
                        else {
                            ai_mode = false;
                            f << ai_mode;
                            initBoard();
                            currentPlayer = 1;
                            selectedR = selectedC = -1;
                            gameState = STATE_PLAYING;
                            moves1 = 0;
                            moves2 = 0;
                        }
                        f.close();
                    }
                }

                if (gameState == STATE_MAIN_MENU) {
                    Vector2i mousePos = Mouse::getPosition(window);

                    // Button positions (same as drawMenu)
                    for (int i = 0; i < 4; i++) {
                        int x = width / 2 - 140;
                        int y = 160 + i * 70;

                        // Check click inside button
                        if (mousePos.x >= x && mousePos.x <= x + 280 &&
                            mousePos.y >= y && mousePos.y <= y + 50)
                        {
                            if (i == 0) {
                                gameState == STATE_MODE;
                                // Select Mode
                            }
                            else if (i == 1) {    // Continue
                                gameState = STATE_PLAYING;
                            }
                            else if (i == 2) {    // Settings
                                gameState = STATE_SETTINGS;
                            }
                            else if (i == 3) {    // Quit
                                saveBoard();
                                window.close();
                            }
                        }
                    }
                }

                if (gameState == STATE_PLAYING) {
                    if (keyPress->code == Keyboard::Key::S) {
                        saveBoard();
                    }
                    if (keyPress->code == Keyboard::Key::L) {
                        loadBoard();
                    }
                    if (keyPress->code == Keyboard::Key::R) {
                        initBoard();
                        currentPlayer = 1;
                        selectedR = -1;
                        selectedC = -1;
                    }
                    if (keyPress->code == Keyboard::Key::Escape) {
                        saveBoard();
                        gameState = STATE_MAIN_MENU;
                        selectedR = -1;
                        selectedC = -1;
                        selectedMenuOption = 0;
                    }
                    if (keyPress->code == Keyboard::Key::Down) {
                        if (ud < 7) {
                            bbox.move({ 0.f, static_cast<float>(height) / 8.f });
                            ud++;
                        }
                    }
                    if (keyPress->code == Keyboard::Key::Up) {
                        if (ud > 0) {
                            bbox.move({ 0.f, static_cast<float>(height) / -8.f });
                            ud--;
                        }
                    }
                    if (keyPress->code == Keyboard::Key::Right) {
                        if (lr < 7) {
                            bbox.move({ static_cast<float>(width) / 8.f, 0.f });
                            lr++;
                        }
                    }
                    if (keyPress->code == Keyboard::Key::Left) {
                        if (lr > 0) {
                            bbox.move({ static_cast<float>(width) / -8.f, 0.f });
                            lr--;
                        }
                    }
                    if (keyPress->code == Keyboard::Key::Enter) {
                        if (1) {
                            Vector2f pos = bbox.getPosition();
                            int c = pos.x / (static_cast<float>(width) / 8.f);
                            int r = pos.y / (static_cast<float>(height) / 8.f);

                            if (inside(r, c)) {
                                if (selectedR == -1) {
                                    if (getPlayer(board[r][c]) == currentPlayer) {
                                        selectedR = r;
                                        selectedC = c;
                                    }
                                }
                                else {
                                    if (makeMove(selectedR, selectedC, r, c, currentPlayer)) {
                                        selectedR = -1;
                                        selectedC = -1;
                                        if (ai_mode) {
                                            if (currentPlayer == 1) {
                                                cout << "Player 1 Moves: " << moves1 << endl;
                                                moves1++;
                                                currentPlayer = 2;
                                            }
                                        }
                                        else {
                                            currentPlayer == 1 ? moves1++ : moves2++;
                                            cout << "Player 1 Moves: " << moves1 << "  Player 2 Moves: " << moves2 << endl;
                                            currentPlayer == 1 ? currentPlayer = 2 : currentPlayer = 1;
                                        }
                                    }
                                    else if (getPlayer(board[r][c]) == currentPlayer) {
                                        selectedR = r;
                                        selectedC = c;
                                    }
                                    else {
                                        selectedR = -1;
                                        selectedC = -1;
                                    }
                                }
                            }
                        }
                    }
                }

                if (gameState == STATE_MAIN_MENU) {
                    if (keyPress->code == Keyboard::Key::Up) {
                        selectedMenuOption = (selectedMenuOption - 1 + 4) % 4;
                    }
                    else if (keyPress->code == Keyboard::Key::Down) {
                        selectedMenuOption = (selectedMenuOption + 1) % 4;
                    }
                    else if (keyPress->code == Keyboard::Key::Enter) {
                        if (selectedMenuOption == 0) {
                            gameState = STATE_MODE;
                            /*initBoard();
                            currentPlayer = 1;
                            selectedR = -1;
                            selectedC = -1;
                            gameState = STATE_PLAYING;*/
                        }
                        else if (selectedMenuOption == 1) {
                            if (loadBoard()) {
                                selectedR = -1;
                                selectedC = -1;
                                gameState = STATE_PLAYING;
                            }
                        }
                        else if (selectedMenuOption == 2) {
                            gameState = STATE_SETTINGS;
                        }
                        else if (selectedMenuOption == 3) {
                            saveBoard();
                            window.close();
                        }
                    }
                }
            }
        }

        if (gameState == STATE_PLAYING) {
            if (currentPlayer == 2 && ai_mode) {
                sleep(milliseconds(100));
                aiMove();
                currentPlayer = 1;
            }

            if (!hasAnyPieces(2) || !hasValidMoves(2)) {
                gameState = STATE_PLAYER_WON;
            }
            else if (!hasAnyPieces(1) || !hasValidMoves(1)) {
                gameState = STATE_PLAYER_LOST;
            }

            window.clear();
            drawBoard(window, static_cast<float>(width) / 8.f, static_cast<float>(height) / 8.f);
            window.draw(bbox);
            window.display();
        }
        else if (gameState == STATE_MAIN_MENU) {
            drawMenu(window, font, width);
        }
        else if (gameState == STATE_SETTINGS) {
            drawSettings(window, font, bbox1, width);
        }
        else if (gameState == STATE_PLAYER_WON || gameState == STATE_PLAYER_LOST) {
            drawEndScreen(window, font, gameState == STATE_PLAYER_WON, (width));
        }
        else if (gameState == STATE_MODE) {
            drawModePage(window, font, bbox3, width);
        }
        else if (gameState == STATE_HSAI) {
            drawHighscoreAi(window, font, width);
        }
        else if (gameState == STATE_HSHUMAN) {
            drawHighscoreHuman(window, font, width);
        }
    }
    return 0;
}
